<?php

# [NOTE]
# 访问控制过程说明
# + 匿名用户拒绝访问
# + 管理员组（sysop）不受限制
# + 只控制 $wgAccessControlNamespaces 列出的空间集合
# + 检查专用页面"Project:页面访问规则", 读取PAR/OAR模板定义的访问规则
# + 将页面名称/对象名称与访问规则顺序匹配, 首个匹配规则生效, 无匹配规则允许访问
# + 页名控制规则（PAR）定义:
#   {{PAR|规则名称|页名模式|读写授权|只读授权}}
#   + "页名模式"使用正则表达式
#       /正则表达式/
#   + "读写权限"和"只读权限"用半角逗号分隔
#       $开头表示用户名, 如: $周京晖
#       @开头表示群组名（用户列表存储在页面"安全:<群组名>", 用户之间用半角逗号或回车分隔）, 如: @过程改进团队（用户列表存储在页面"安全:过程改进团队"）
#       &函数名（是否允许访问自定义插件提供的以"ACF_"开头的PHP权限控制函数决定）, 如: &xxx -> ACF_xxx()
# + 对象控制规则（OAR）定义:
#   {{OAR|对象名称|引用属性|读写授权|只读授权}}
#   + "对象名称"通过目标页面是否属于"分类:<对象名称>的实例"来判断
#   + "读写权限"和"只读权限"的定义同上

# 定义"Special:Version"中的记录
$wgExtensionCredits['parserhook'][] = array(
    'path'           => __FILE__,
    'name'           => 'AccessControl',
    'author'         => '周京晖',
    'url'            => 'http://xxx',
    'version'        => '0.1',
    'descriptionmsg' => 'accesscontrol-desc'
);

# 定义本地化消息
$wgMessagesDirs['AccessControl'] = __DIR__ . '/i18n';
$wgExtensionMessagesFiles['AccessControl'] = __DIR__ . '/AccessControl.i18n.php'; # MediaWiki-1.23+ 建议使用i18n/*.json

# 注册钩子函数
$wgHooks['ParserFirstCallInit'][] = 'wfInitAccessControl';
// $wgHooks['userCan'][] = 'OnHook_UserCan';
// $wgHooks['titleQuickPermissions'][] = 'OnHook_TitleQuickPermissions'; -> TODO
$wgHooks['getUserPermissionsErrors'][] = 'OnHook_GetUserPermissionsErrors';

# 定义权限检查的空间
$wgAccessControlNamespaces = array();

# 初始化
function wfInitAccessControl(Parser $parser)
{
    return true;
}

# 权限判断钩子
function OnHook_UserCan(&$title, &$user, $action, &$result)
{
    # NOTE:
    # 本函数返回值
    #   true  : 继续后续检查
    #   false : 停止后续检查
    # 本函数返回参数: $result
    #   1 : 允许
    #   0 : 拒绝(不要拒绝, 否则后续重定向等操作受影响)
    # 参考: includes/Title.php -> function userCan()

    $page_name = $title->getText();
    my_trace("--------- OnHook_UserCan: $page_name($action) ---------");

    $priv_tag = get_user_priv($user, $title);

    if ($priv_tag == 'RW') {
        return true;
    }

    if ($priv_tag == 'RO') {
        set_readonly();
        return true;
    }

    // NO + ...
    set_rejected();
    return false;
}

# 权限判断钩子
function OnHook_GetUserPermissionsErrors($title, $user, $action, &$result)
{
    # 忽略资源对象, 如: Null/loading.gif
    if ($title->mArticleID == 0) {
        return true;
    }

    $page_name = $title->getText();
    my_trace("--------- OnHook_GetUserPermissionsErrors: $page_name($action) ---------");

    $priv_tag = get_user_priv($user, $title);

    if ($action == 'read') {
        if ($priv_tag == 'NO') {
            $result = '无权查看';
            return false;
        }
        return true;
    }

    if ($action == 'edit') {
        if ($priv_tag != 'RW') {
            $result = '无权编辑';
            return false;
        }
        return true;
    }

    return true;
}

#-------------------------------------------------------------------------------

# 获取用户($user)对页面($title)的访问权限(RW, RO, NO)
function get_user_priv($user, $title)
{
    # 获取页面信息
    $page_name = $title->getText();

    $ns_id = $title->getNamespace();
    if ($ns_id < 0) {
        $full_page_name = "特殊:$page_name";
    } elseif ($ns_id == 0) {
        $full_page_name = $page_name;
    } else {
        global $wgExtraNamespaces;
        if (array_key_exists($ns_id, $wgExtraNamespaces)) {
            $ns_name = $wgExtraNamespaces[$ns_id];
            $full_page_name = "$ns_name:$page_name";
        } else {
            $full_page_name = "$ns_id:$page_name";
        }
    }

    # 检查权限缓存 => 单次界面访问可能多次内部调用
    static $last_user_id   = null;
    static $last_page_name = null;
    static $last_priv_tag  = null;

    if ($last_user_id === $user->mId and $last_page_name === $full_page_name)
    {
        # my_trace("CACHE HIT: priv = $last_priv_tag");
        return $last_priv_tag;
    }

    $last_user_id = $user->mId;
    $last_page_name = $full_page_name;

    # 快速检查

    # 0) 拒绝匿名用户
    if ($user->mId == 0) {
        // NOTE: 允许匿名用户登录
        // my_trace("NO: anonymous user");
        // $last_priv_tag = 'NO';
        // return $last_priv_tag;
        return 'RO';
    }

    # 1) 允许管理员组
    if (in_array('sysop', $user->getGroups(), true)) {
        my_trace("RW: administrator");
        $last_priv_tag = 'RW';
        return $last_priv_tag;
    }

    # 2) 只检查设定的名字空间
    global $wgAccessControlNamespaces;
    if (!in_array($ns_id, $wgAccessControlNamespaces, true)) {
        # my_trace("RW: $full_page_name NOT in \$wgAccessControlNamespaces");
        $last_priv_tag = 'RW';
        return $last_priv_tag;
    }

    # 权限检查

    # 读取预定义规则
    $AR_content = my_read_page(NS_PROJECT, '页面访问规则', 1); # PAR => Page Access Rules
    # my_trace("AR_content = $AR_content");
    if (empty($AR_content)) {
        my_trace("RW: NO PAR or OAR found");
        $last_priv_tag = 'RW';
        return $last_priv_tag;
    }

    # 依次匹配规则
    $match = 0;

    # 页名访问规则
    preg_match_all('/\*基于页名的访问控制\n:规则名称 = \'\'\'([^\n]*)\'\'\'\n:页名模式 = ([^\n]*)\n:读写授权 = ([^\n]*)\n:只读授权 = ([^\n]*)(\n|$)/s', $AR_content, $PAR_rules, PREG_SET_ORDER);
    foreach ($PAR_rules as $rule) {
        $rule_name     = $rule[1];
        $match_pattern = $rule[2]; # {{PAR|维基用户的个人页面|/^用户:([^\/]+)\//|$1|NULL}} => 用户:Zhoujh/xxx以$1(user=Zhoujh)的方式引用
        $write_list    = $rule[3];
        $read_list     = $rule[4];

        # my_trace("TRY: $rule_name : PATTERN = $match_pattern, WRITE_LIST = ($write_list), READ_LIST = ($read_list)");

        if (preg_match($match_pattern, $full_page_name, $matches)) {
            my_trace("MATCHED PAGE RULE = $rule_name, PATTERN = $match_pattern, WRITE_LIST = ($write_list), READ_LIST = ($read_list)");
            $match = 1;
            break;
        }
    }

    # 对象访问规则
    if ($match == 0) {
        preg_match_all('/\*基于对象的访问控制\n:对象名称 = \'\'\'([^\n]*)\'\'\'\n:引用属性 = ([^\n]*)\n:读写授权 = ([^\n]*)\n:只读授权 = ([^\n]*)(\n|$)/s', $AR_content, $OAR_rules, PREG_SET_ORDER);
        foreach ($OAR_rules as $rule) {
            $object_name   = $rule[1];
            $refer_props   = $rule[2]; # {{OAR|文档资料|访问控制|@1|@1}} => 【文档资料】xxx以@1(group=周京晖,开发应用室)的方式引用
            $write_list    = $rule[3];
            $read_list     = $rule[4];

            # my_trace("TRY: $object_name : PROPS = $refer_props, WRITE_LIST = ($write_list), READ_LIST = ($read_list)");

            $categories = my_expand_text("{{#show:$full_page_name|?分类#}}");
            if (strstr($categories, "分类:${object_name}的实例")) {
                $matches = preg_split('/[\s,]+/', $refer_props);
                foreach ($matches as &$prop) {
                    $prop = my_expand_text("{{#show:$full_page_name|?${object_name}的${prop}#}}");
                }
                array_unshift($matches, $full_page_name);
                my_trace("MATCHED OBJECT RULE = $object_name, REFER_PROPS = $refer_props, WRITE_LIST = ($write_list), READ_LIST = ($read_list)");
                $match = 1;
                break;
            }
        }
    }

    if ($match == 0) {
        my_trace("RW: NO PAR or OAR matched");
        $last_priv_tag = 'RW';
        return $last_priv_tag;
    }

    # 匹配用户组
    if (check_priv('RW', $user, $ns_id, $page_name, $write_list, $matches)) {
        $last_priv_tag = 'RW';
        return $last_priv_tag;
    }
    if (check_priv('RO', $user, $ns_id, $page_name, $read_list, $matches)) {
        $last_priv_tag = 'RO';
        return $last_priv_tag;
    }

    # 无权访问
    my_trace("DENY: $user->mName NOT in ($write_list) or ($read_list)");

    $last_priv_tag = 'NO';
    return $last_priv_tag;
}

function check_priv($mode, $user, $ns_id, $page_name, $member_list, $matches)
{
    $user_name = strtolower($user->mName);

    $allow_members = preg_split('/[\s,]+/', $member_list);
    foreach ($allow_members as $member) {
        my_trace("$mode member = '$member'");

        if (empty($member)) {
            continue;
        }

        if ($member == 'NULL') {
            continue;
        }

        if ($member == 'ALL') {
            my_trace("$mode(V): $user_name in ($member_list)");
            return true;
        }

        $prefix = substr($member, 0, 1);
        $member = replace_member(substr($member, 1), $matches); # $1 -> xxx OR xxx, yyy, zzz
        switch ($prefix) {
        case '$':
            $user_members = preg_split('/,/', $member);
            foreach ($user_members as $each_user) {
                if ($user_name == strtolower($each_user)) {
                    my_trace("$mode(V): $user_name in ($member)");
                    return true;
                }
            }
            my_trace("$mode(X): $user_name NOT in ($member)");
            break;
        case '@':
            $group_members = preg_split('/,/', $member);
            $all_group_users = [];
            foreach ($group_members as $each_group) {
                $group_users = preg_split('/[\s,]+/', my_read_page(MY_NS_ACE, $each_group, 1));
                $all_group_users = array_merge($all_group_users, $group_users);
                foreach ($group_users as $each_user) {
                    if ($user_name == strtolower($each_user)) {
                        my_trace("$mode(V): $user_name in $member(" . implode(',', $all_group_users) . "...)");
                        return true;
                    }
                }
            }
            my_trace("$mode(X): $user_name NOT in $member(" . implode(',', $all_group_users) . ")");
            break;
        case '&':
            $check_func = 'ACF_' . $member;
            if (!function_exists($check_func)) {
                my_trace("$mode(!): UNDEFINED function: '$check_func()'");
                break;
            }
            if ($check_func($mode, $ns_id, $page_name, $user_name, $matches, sizeof($allow_members)>1?1:0)) {
                my_trace("$mode(V): $user_name is GRANTED by $check_func($mode)");
                return true;
            }
            my_trace("$mode(X): $user_name is REJECTED by $check_func($mode)");
            break;
        default:
            my_trace("$mode(!): UNKNOWN member: '$member' in ($member_list)");
            break;
        }
    }

    return false;
}

# replace $1,$2,$3,... with regex match component
function replace_member($member, $matches)
{
    if (strlen($member) != 1) {
        return $member;
    }

    $index = $member + 0;
    if ($index <= 0) {
        return $member;
    }

    return $matches[$index];
}

function set_readonly()
{
    # 操作列表
    # recreatedata =
    # pagevalues =
    # editschema =
    # generatepages =
    # formedit = 用表单编辑页面
    # formcreate = 用表单创建页面
    # credits =
    # delete = 删除页面
    # edit = 编辑页面
    # editchangetags =
    # history = 查看历史                => READONLY
    # info =
    # markpatrolled = 标注为已巡视
    # protect = 保护页面
    # purge = 强制刷新                  => READONLY
    # raw =
    # render =
    # revert =
    # revisiondelete =
    # rollback = 回滚
    # submit = 提交
    # unprotect = 取消保护
    # unwatch = 取消关注
    # view = 查看页面                   => READONLY
    # watch = 关注
    # visualeditor = 新一代编辑器

    global $wgActions;
    foreach ($wgActions as $key => &$value) {
        # my_trace("ACTION: $key = $value");
        $value = false;
    }
    unset($value);

    $wgActions['visualeditor'] = false;

    # 禁止编辑(edit,formedit,rollback), 移动(move)等操作
    $wgActions['view']    = true; # 查看
//  $wgActions['history'] = true; # 历史
//  $wgActions['purge']   = true; # 刷新
}

function set_rejected()
{
    global $wgActions;
    foreach ($wgActions as $key => &$value) {
        $value = false;
    }
    unset($value);
}

function my_read_page($ns_id, $page_name, $expand)
{
    $title = Title::makeTitleSafe($ns_id, $page_name);
    if ($title == null) {
        return false;
    }

    $page = WikiPage::factory($title);
    if ($page == null) {
        return false;
    }

    $content = $page->getContent();
    if ($content == null) {
        return false;
    }

    $page_text = $content->getNativeData();

    if ($expand) {
        global $wgParser, $wgUser;
        if (empty($wgParser->mOptions)) {
            $wgParser->startExternalParse($title, ParserOptions::newFromUser($wgUser), Parser::OT_PREPROCESS);
        }
        $page_text = $wgParser->replaceVariables($page_text);
    }

    # my_trace(">>>>>>>>> $page_name <<<<<<<<<\n$page_text\n");

    return $page_text;
}

function my_expand_text($text)
{
    global $wgParser, $wgUser;
    if (empty($wgParser->mOptions)) {
        $wgParser->startExternalParse(null, ParserOptions::newFromUser($wgUser), Parser::OT_PREPROCESS);
    }
    return $wgParser->replaceVariables($text);
}

function my_explode($delimiter, $string)
{
    $all_members = explode($delimiter, $string);

    foreach ($all_members as &$member) {
        $member = trim($member, " \t\n\r\0\x0B,");
    }
    unset($member);

    return $all_members;
}

function my_trace($string)
{
    wfDebugLog('ace', $string);
}

#-------------------------------------------------------------------------------
# 自定义的PAR权限检查函数
#-------------------------------------------------------------------------------

function ACF_ACL($mode, $ns_id, $page_name, $user_name, $matches, $other_exist)
{
    # my_trace("mode = $mode, ns_id = $ns_id, page_name = $page_name, user_name = $user_name, other_exist = $other_exist");

    # 读取目标页面内容
    $page_content = my_read_page($ns_id, $page_name, 0);

    # my_trace("page_content = '$page_content'");

    # 提取访问控制字段: | ACL = [^\n|}]*
    if (!preg_match('/\|\s*ACL\s*=\s*([^\n\|\}]*)/', $page_content, $limit_list)) {
        # NO limit
        my_trace(__FUNCTION__ . ": ACL NOT found");
        return !$other_exist; # 如果访问列表仅本函数且无ACL字段则返回true(任何人可以访问)
    }

    my_trace("limit_list = '$limit_list[1]'");

    # 判断用户权限
    $member_count = 0;
    $limit_members = my_explode(',', $limit_list[1]);
    foreach ($limit_members as $member) {
        if (empty($member)) {
            continue;
        }

        my_trace("member = '$member'");

        $member_content = my_read_page(MY_NS_ACE, $member, 1); # ACL中全是群组,没有用户
        if ($member_content === false) {
            # $member是个人
            if ($user_name == $member) {
                my_trace(__FUNCTION__ . ": $user_name in ($limit_list[1])");
                return true;
            }
        } else {
            # member是群组
            $limit_users = preg_split('/[\s,]+/', $member_content);
            if (in_array($user_name, $limit_users, true)) {
                my_trace(__FUNCTION__ . ": $user_name in $member(" . implode(',', $limit_users) . ")");
                return true;
            }
        }

        $member_count ++;
    }

    return !$other_exist and !$member_count; # 如果访问列表仅有本函数且ACL字段为空则返回true(任何人可以访问)
}
/*
function ACF_UserLeader($mode, $ns_id, $page_name, $user_name, $matches, $other_exist)
{
    # my_trace("mode = $mode, ns_id = $ns_id, page_name = $page_name, user_name = $user_name, other_exist = $other_exist");

    # 提取被访问用户
    $visit_user = $matches[1];

    # 查询被访问用户的团队领导集合
    $visit_user_leaders = my_expand_text("{{#ask:[[分类:XX团队的实例]][[XX团队的名称::{{#show:$visit_user|?XX用户的所属团队#|sep={{!!}}|default=?}}]]|mainlabel=-|?XX团队的领导#=}}");

    # 当前用户是否被访问用户的领导?
    if (in_array($user_name, my_explode(',', $visit_user_leaders))) {
        return true;
    }

    # 查询被访问用户的团队助理集合
    $visit_user_assistants = my_expand_text("{{#ask:[[分类:XX团队的实例]][[XX团队的名称::{{#show:$visit_user|?XX用户的所属团队#|sep={{!!}}|default=?}}]]|mainlabel=-|?XX团队的助理#=}}");

    # 当前用户是否被访问用户的助理?
    if (in_array($user_name, my_explode(',', $visit_user_assistants))) {
        return true;
    }

    return false;
}

function ACF_TeamLeader($mode, $ns_id, $page_name, $user_name, $matches, $other_exist)
{
    # my_trace("mode = $mode, ns_id = $ns_id, page_name = $page_name, user_name = $user_name, other_exist = $other_exist");

    # 提取被访问团队
    $visit_team = $matches[1];

    # 查询被访问团队的领导
    $visit_team_leader = my_expand_text("{{#show:$visit_team|?XX团队的领导#}}");

    # 当前用户是否被访问团队的领导?
    if ($user_name == $visit_team_leader) {
        return true;
    }

    # 查询被访问团队的领导
    $visit_team_assistants = my_expand_text("{{#show:$visit_team|?XX团队的助理#}}");

    # 当前用户是否被访问团队的领导?
    if ($user_name == $visit_team_assistants) {
        return true;
    }

    return false;
}

function ACF_ProjectLeader($mode, $ns_id, $page_name, $user_name, $matches, $other_exist)
{
    # my_trace("mode = $mode, ns_id = $ns_id, page_name = $page_name, user_name = $user_name, other_exist = $other_exist");

    # 提取被访问项目
    $visit_project = $matches[1];

    # 查询被访问项目的领导
    $visit_project_leader = my_expand_text("{{#show:$visit_project|?XX项目的项目经理#}}");

    # 当前用户是否被访问项目的领导?
    return $user_name == $visit_project_leader;
}

function ACF_DepartmentLeader($mode, $ns_id, $page_name, $user_name, $matches, $other_exist)
{
    # my_trace("mode = $mode, ns_id = $ns_id, page_name = $page_name, user_name = $user_name, other_exist = $other_exist");

    # 提取被访问部门
    $visit_department = $matches[1];

    # 查询被访问部门的领导
    $visit_department_leader = my_expand_text("{{#show:$visit_department|?XX部门的领导#}}");

    # 当前用户是否被访问部门的领导?
    return $user_name == $visit_department_leader;
}

function ACF_QueryReport($mode, $ns_id, $page_name, $user_name, $matches, $other_exist)
{
    my_trace("mode = $mode, ns_id = $ns_id, page_name = $page_name, user_name = $user_name, other_exist = $other_exist");

    $query_name = substr($page_name, strlen("执行查询/"));
    $reporter = $_REQUEST[$query_name][1];

    if ($user_name == $reporter) {
        # 允许查看自己的报告
        my_trace("$user_name is user($reporter) himself");
        return true;
    }

    $user_leaders = my_expand_text("{{#ask:[[分类:XX团队的实例]][[XX团队的名称::{{#show:$reporter|?XX用户的所属团队#|sep={{!!}}|default=?}}]]|mainlabel=-|?XX团队的领导#=}}");
    if (in_array($user_name, explode(', ', $user_leaders))) {
        # 团队领导允许查看下属的报告
        my_trace("$user_name is user($reporter)'s leader");
        return true;
    }
    $user_assistants = my_expand_text("{{#ask:[[分类:XX团队的实例]][[XX团队的名称::{{#show:$reporter|?XX用户的所属团队#|sep={{!!}}|default=?}}]]|mainlabel=-|?XX团队的助理#=}}");
    if (in_array($user_name, explode(', ', $user_assistants))) {
        # 团队助理允许查看下属的报告
        my_trace("$user_name is user($reporter)'s assistant");
        return true;
    }

    $team_leader = my_expand_text("{{#show:$reporter|?XX团队的领导#}}");
    if ($user_name == $team_leader) {
        # 团队领导允许查看团队的报告
        my_trace("$user_name is team($reporter)'s leader");
        return true;
    }
    $team_assistant = my_expand_text("{{#show:$reporter|?XX团队的助理#}}");
    if ($user_name == $team_assistant) {
        # 团队助理允许查看团队的报告
        my_trace("$user_name is team($reporter)'s assistant");
        return true;
    }

    $project_leader = my_expand_text("{{#show:$reporter|?XX项目的项目经理#}}");
    if ($user_name == $project_leader) {
        # 项目领导允许查看项目的报告
        my_trace("$user_name is project($reporter)'s leader");
        return true;
    }

    $department_leader = my_expand_text("{{#show:$reporter|?XX部门的领导#}}");
    if ($user_name == $department_leader) {
        # 部门领导允许查看部门的报告
        my_trace("$user_name is department($reporter)'s leader");
        return true;
    }

    # 团队主页的多人汇总查询
    if (strstr($reporter, ',')) {
        $group_users = explode(', ', $reporter);
        foreach ($group_users as $one_user) {
            $user_leaders = my_expand_text("{{#ask:[[分类:XX团队的实例]][[XX团队的名称::{{#show:$one_user|?XX用户的所属团队#|sep={{!!}}|default=?}}]]|mainlabel=-|?XX团队的领导#=}}");
            if (in_array($user_name, explode(', ', $user_leaders))) {
                # 多人中任意人的领导可以进行汇总查询
                my_trace("$user_name is one user($one_user)'s leader");
                return true;
            }
            $user_assistants = my_expand_text("{{#ask:[[分类:XX团队的实例]][[XX团队的名称::{{#show:$one_user|?XX用户的所属团队#|sep={{!!}}|default=?}}]]|mainlabel=-|?XX团队的助理#=}}");
            if (in_array($user_name, explode(', ', $user_assistants))) {
                # 多人中任意人的助理可以进行汇总查询
                my_trace("$user_name is one user($one_user)'s assistant");
                return true;
            }
        }
    }

    my_trace("$user_name is nothing to do with reporter($reporter)");
    return false;
}
*/
