<?php

/**
 * 将简单的笔记文本(NoteText)转换为维基代码(WikiText), NoteText源码的可读性强于WikiText和Markdown源码
 *
 * 维基百科开发文档 => https://doc.wikimedia.org/
 *                   https://doc.wikimedia.org/mediawiki-core/master/php/
 *                   https://doc.wikimedia.org/mediawiki-core/master/js/
 * 扩展标签开发指南 => https://www.mediawiki.org/wiki/Manual:Tag_extensions
 */

if (!defined('MEDIAWIKI'))
{
    die("This is a MediaWiki extension, don't run it directly!");
}

# 用于在"Special:Version"中显示信息
# 'specialpage' —> reserved for additions to MediaWiki Special Pages;
# 'parserhook'  —> used if your extension modifies, complements, or replaces the parser functions in MediaWiki;
# 'variable'    —> extension that add multiple functionality to MediaWiki;
# 'media'       —> used if your extension is a media handler of some sort
# 'api'         -> api modules
# 'other'       —> all other extensions
$wgExtensionCredits['parserhook'][] = array(
    'path'           => __FILE__,
    'name'           => 'My Note Extension',
    'version'        => '1.0',
    'author'         => 'zhoujh',
    'url'            => 'https://www.mediawiki.org/wiki/Extension:MyNoteExt',
    'descriptionmsg' => 'my-note-ext-desc-key', # Message key in i18n file, 必须: 唯一, 小写, 无空格
    'description'    => 'This extension converts note text to wiki text',
);

$wgMessagesDirs['MyNoteExt'] = __DIR__ . '/i18n';

#-------------------------------------------------------------------------------

$wgHooks['ParserFirstCallInit'][] = 'wfMyNoteExtInit';

function wfMyNoteExtInit(Parser $parser)
{
    $parser->setHook('MyNoteCode',   'wfRender_myNoteCode'); # NOTE: 标签<MyNoteCode>不区分大小写
    $parser->setHook('my-note-code', 'wfRender_myNoteCode'); # NOTE: 标签<my-note-code>不区分大小写
    $parser->setHook('my_note_code', 'wfRender_myNoteCode'); # NOTE: 标签<my_note_code>不区分大小写

    $parser->setHook('MyNoteText',   'wfRender_myNoteText'); # NOTE: 标签<MyNoteText>不区分大小写
    $parser->setHook('my-note-text', 'wfRender_myNoteText'); # NOTE: 标签<my-note-text>不区分大小写
    $parser->setHook('my_note_text', 'wfRender_myNoteText'); # NOTE: 标签<my_note_text>不区分大小写

    $parser->setHook('Note',      'wfRender_myNoteText'); # NOTE: 标签<Note>不区分大小写
    $parser->setHook('MyNote',    'wfRender_myNoteText'); # NOTE: 标签<MyNote>不区分大小写
    $parser->setHook('Note2Wiki', 'wfRender_myNoteText'); # NOTE: 标签<Note2Wiki>不区分大小写

    return true;
}

function wfRender_myNoteCode($input, array $args, Parser $parser, PPFrame $frame)
{
    # NOTE:
    # 1)返回可能缓存
    # 2)下列语法不被解析: ~~~/~~~~/~~~~~, PipeTrick, {{subst:}}
    # 3)WikiText不被解析
    # 4)返回值还需如下处理:
    #   替换Strip markers(类似UNIQe62a6957e0dbf6e-item-53--QINU, 用于移除内容的回归)
    #   替换'* xxx'为列表, 替换' xxx'为'<pre>xxx</pre>'

    $sEscapedInputText = str_replace(['<', '>'], ['&lt;', '&gt;'], $input);

    return '<pre>' . $sEscapedInputText . '</pre>';
}

function wfRender_myNoteText($input, array $args, Parser $parser, PPFrame $frame)
{
    # NOTE:
    # 1)返回可能缓存
    # 2)下列语法不被解析: ~~~/~~~~/~~~~~, PipeTrick, {{subst:}}
    # 3)WikiText不被解析
    # 4)返回值还需如下处理:
    #   替换Strip markers(类似UNIQe62a6957e0dbf6e-item-53--QINU, 用于移除内容的回归)
    #   替换'* xxx'为列表, 替换' xxx'为'<pre>xxx</pre>'

    // prepare
    $sInputFile  = tempnam('/tmp', 'input_note_');
    $sOutputFile = tempnam('/tmp', 'output_note_');

    $sScript = __DIR__ . "/tools/Note2Wiki.pl";
    $sCommand = "$sScript $sInputFile $sOutputFile 2>&1";

    // execute
    file_put_contents($sInputFile, $input);

    exec($sCommand, $aOutput, $nRetval);

    if ($nRetval === 0)
    {
        $sOutputText = $parser->recursiveTagParse(file_get_contents($sOutputFile), $frame); # NOTE: 主要耗时操作(90%以上)
    }
    else
    {
        $sCmdOut = implode("\n", $aOutput);
        $sOutputText = "<pre>笔记文本转换失败: RetVal = $nRetval, Output = $sCmdOut</pre>";
    }

    unlink($sInputFile);
    unlink($sOutputFile);

    return $sOutputText;
}
