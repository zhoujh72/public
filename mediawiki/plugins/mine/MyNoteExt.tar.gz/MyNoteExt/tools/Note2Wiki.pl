#!/usr/bin/perl -w

use strict;
use warnings;

#-------------------------------------------------------------------------------
# 笔记文本转换工具: 笔记文件 -> 特定格式(MediaWiki/...)的源码文件
#-------------------------------------------------------------------------------

# 笔记文本的格式说明:
#
# 笔记内容分为下列类型: <标题>, <文本>, <命令>, <代码>, <特殊>
# + <标题>以'+ '开头, 其它类型都属于(内容), 包括: <文本>, <命令>, <代码>, <特殊>
#       + 1级标题 -> 顶头
#          + 2级标题 -> 缩进1级
#               + 3级标题 -> 缩进2级
# + (内容)的缩进级数等于所属<标题>的缩进级数+1
#       + 标题
#           正文块1 -> 内容='正文块1'
#             正文块2 -> 内容='  正文块2' -> NOTE: 前导空格应用维基语法
#                 正文块3 -> 内容='    正文块3' -> NOTE: 实测显示同(1)
#   NOTE: 目前未考虑(内容)缩进超过4个空格的情况, 此时(内容)的缩进级数 > <标题>的缩进级数+1
# + <命令>以'$ '开头, 后续相邻的缩进级数*更深*的<文本>块视为该<命令>的附属<代码>块
#       $ yum install gcc -> 普通命令
#       $ ls -l -> 普通命令
#           @+  -> 输出折叠指令: @+表示总是折叠, @-表示总是展开, 缺省超过10000行(含)折叠
#           xxx -> 输出内容
#       $ vi abc # lang=c -> 文件的语法是C语言
#           xxx -> 文件内容
# + <文本>中的格式规则:
#       加粗: <*粗体*>
#       斜体: </斜体/>
#       下线: <_下划_>
#       删线: <-删除->
#       上标: <^上标^>
#       下标: <.下标.>
#       粗斜: <*/粗斜/*> -> 其它类推(最多3种)...
#       参数: <%参数%>
#       代码: <~代码(不解析wiki语法)~> <#代码(解析wiki语法)#>
#       行尾注释: ' # ' -> #以后的内容转换为注释块
#       单行注释: '@# ' -> 不能用有序标号#和维基表格的表头标记!
#       单行警告: '@WARN:'
#       单行信息: '@INFO:' -> 兼容@NOTE:
#       单行提示: '@HINT:'
#       单行TODO: '@TODO:'
#       单行参考: '@REF:'
#       行首符号: '-> '转换为'→ '
#                 '=> '转换为'⇒ ' NOTE: 本字体无法显示, 实际为双杆箭头: &rArr;
#                 'o '转换为'¤ '
#                 'O '转换为'☼ '
#       HTML标签: 由MediaWiki自行转换
# + <特殊>指令
#       __DBG__: 页尾输出转换结果
#       __TOC__: 强制生成目录
#       __END__: 强制生成尾节
#
# 维基笔记的特殊块:
# + 单行@code:表示后续内容已经是代码文本
#       @code:
#           <语种>
#           @+ -> 初始折叠(@+)或展开(@-)代码
#           这里的内容已经是代码文本, 删除当前缩进后用适合的代码标签(<source>, <geshi>, <pre>)包围
# + 单行@table:表示后续内容是维基表格, 各列以'|'或'~'(建议用于跨行的视觉标识)分隔, 表头以#后缀
#       @table:
#           CSS类>>> -> 每个>表示额外缩进1级
#           *表头*   | *表头*{样式} | *表头*[跨列数x跨行数] | *表头*[跨列数x跨行数]{样式}  -> 兼容: !表头
#            单元    |  单元{样式}  |  单元[跨列数x跨行数]  |  单元[跨列数x跨行数]{样式}
#       特殊处理:
#           K = V -> K-V两列(K中没有|)
#           ---   -> 通栏跨列
#   NOTE: 空白单元要求填入类似&nbsp;的文本
# + 单行@raw:表示后续内容已经是目标文本
#       @raw: -> 兼容@wiki, @rawtext, @wikitext
#           这里的内容已经是目标文本, 删除当前缩进后直接输出
#       `单行目标文本
# + 单行@keys:表示后缀内容是笔记标签(MediaWiki处理为维基分类) -> 兼容@keywords, @tags:
# + 注释块(由MediaWiki处理)
#       <!--
#           注释文本由MediaWiki忽略
#       -->
#
# 内部定义的"图像/模板/CSS类"如下
# + 图像: note-warn.png, note-info.png, note-hint.png, note-ref.png, note-todo.png
# + 模板: 自动笔记页尾
# + CSS类: indent_N, note_variable, note_comment, note_warn, note_info, note_hint, note_todo, note_reference

#-------------------------------------------------------------------------------
# Import Modules
#-------------------------------------------------------------------------------

use utf8;

use POSIX;
use Encode;
use Encode::CN; # pp需要
use File::Basename;
use Data::Dumper;

use My::Common;

#-------------------------------------------------------------------------------
# Global Constants
#-------------------------------------------------------------------------------

# element types
use constant {
    ET_RETURN    => 'RETURN  ', # 空行
    ET_TITLE     => 'TITLE   ', # 主标题
    ET_SUBTITLE  => 'SUBTITLE', # 子标题
    ET_TEXT      => 'TEXT    ', # 文本
    ET_COMMAND   => 'COMMAND ', # 命令
    ET_CODE      => 'CODE    ', # 代码
    ET_TABLE     => 'TABLE   ', # 表格
    ET_RAWTEXT   => 'RAWTEXT ', # 目标文本
};

# parser configurations
my %CONF = (
    DEBUG => 0,

    OUTPUT_FORMAT => 'MediaWiki', # 输出格式 = MediaWiki

    MAX_TITLE_LEVEL    => 3, # 维基页面主标题的最大级数, 超过则以"缩进+无序列表"的"子标题"实现
    MAX_SUBTITLE_LEVEL => 3, # 维基页面子标题的最大级数, 超过则视为<内容> = <文本> + <命令> + <代码> + <特殊>
    MAX_FOLD_DEPTH     => 1, # 折叠区域的缺省深度(0=不折叠, 1=折叠首级主标题, N=折叠1~N级主标题)

    INDENT_WIDTH => 4, # TAB缩进 = 4空格
    INDENT_STRING => ' ' x 4,

    MIN_COLLAPSE_LINES => 10000, # NOTE: 目前已经通过CSS样式自动滚动高度超过500px的代码, 因此折叠功能已成鸡肋
);

# code language aliases
my %EXT_TO_LANG = (
    'sh'  => 'shell',
    'vba' => 'vb',
    'bas' => 'vb',
);

my %ALL_SUPPORT_LANGS = (
    source => [
        # get from: $WIKI_HOME/extensions/SyntaxHighlighter/SyntaxHighlighter.php/$syntaxAlias
        'cpp', 'c', 'csharp', 'c-sharp', 'css', 'php', 'text', 'plain', 'xml', 'html', 'xhtml', 'xslt', 'sql', 'ps',
        'powershell', 'perl', 'pl', 'delphi', 'python', 'py', 'ruby', 'rb', 'diff', 'js', 'jscript', 'javascript', 'bash',
        'shell', 'java',
    ],
    geshi => [
        # get from: $WIKI_HOME/extensions/SyntaxHighlight_GeSHi/SyntaxHighlight_GeSHi.lexers.php
        'abap', 'abl', 'abnf', 'aconf', 'actionscript', 'actionscript3', 'ada', 'ada2005', 'ada95', 'adl', 'agda', 'ahk',
        'alloy', 'ambienttalk', 'ambienttalk/2', 'antlr', 'antlr-actionscript', 'antlr-as', 'antlr-c#', 'antlr-cpp',
        'antlr-csharp', 'antlr-java', 'antlr-objc', 'antlr-perl', 'antlr-python', 'antlr-rb', 'antlr-ruby', 'apache',
        'apacheconf', 'apl', 'applescript', 'arduino', 'arexx', 'as', 'as3', 'asm', 'aspectj', 'aspx-cs', 'aspx-vb',
        'asy', 'asymptote', 'at', 'autohotkey', 'autoit', 'awk', 'b3d', 'basemake', 'bash', 'basic', 'bat', 'batch',
        'bbcode', 'bc', 'befunge', 'bf', 'blitzbasic', 'blitzmax', 'bmax', 'bnf', 'boo', 'boogie', 'bplus', 'brainfuck',
        'bro', 'bsdmake', 'bugs', 'c', 'c#', 'c++', 'c++-objdumb', 'c-objdump', 'ca65', 'cadl', 'camkes', 'cbmbas',
        'ceylon', 'cf3', 'cfc', 'cfengine3', 'cfg', 'cfm', 'cfs', 'chai', 'chaiscript', 'chapel', 'cheetah', 'chpl',
        'cirru', 'cl', 'clay', 'clipper', 'clj', 'cljs', 'clojure', 'clojurescript', 'cmake', 'cobol', 'cobolfree',
        'coffee', 'coffee-script', 'coffeescript', 'common-lisp', 'componentpascal', 'console', 'control', 'coq', 'cp',
        'cpp', 'cpp-objdump', 'cpsa', 'crmsh', 'croc', 'cry', 'cryptol', 'csh', 'csharp', 'csound', 'csound-csd',
        'csound-document', 'csound-orc', 'csound-sco', 'csound-score', 'css', 'css+django', 'css+erb', 'css+genshi',
        'css+genshitext', 'css+jinja', 'css+lasso', 'css+mako', 'css+mozpreproc', 'css+myghty', 'css+php', 'css+ruby',
        'css+smarty', 'cu', 'cucumber', 'cuda', 'cxx-objdump', 'cypher', 'cython', 'd', 'd-objdump', 'dart', 'debcontrol',
        'debsources', 'delphi', 'dg', 'diff', 'django', 'docker', 'dockerfile', 'dosbatch', 'doscon', 'dosini', 'dpatch',
        'dtd', 'duby', 'duel', 'dylan', 'dylan-console', 'dylan-lid', 'dylan-repl', 'earl-grey', 'earlgrey', 'easytrieve',
        'ebnf', 'ec', 'ecl', 'eg', 'eiffel', 'elisp', 'elixir', 'elm', 'emacs', 'erb', 'erl', 'erlang', 'evoque', 'ex',
        'exs', 'ezhil', 'factor', 'fan', 'fancy', 'felix', 'fish', 'fishshell', 'flx', 'fortran', 'fortranfixed',
        'foxpro', 'fsharp', 'fy', 'gap', 'gas', 'gawk', 'genshi', 'genshitext', 'gherkin', 'glsl', 'gnuplot', 'go',
        'golo', 'gooddata-cl', 'gosu', 'groff', 'groovy', 'gst', 'haml', 'handlebars', 'haskell', 'haxe', 'haxeml',
        'hexdump', 'hs', 'html', 'html+cheetah', 'html+django', 'html+erb', 'html+evoque', 'html+genshi',
        'html+handlebars', 'html+jinja', 'html+kid', 'html+lasso', 'html+mako', 'html+myghty', 'html+php', 'html+ruby',
        'html+smarty', 'html+spitfire', 'html+twig', 'html+velocity', 'htmlcheetah', 'htmldjango', 'http', 'hx', 'hxml',
        'hxsl', 'hy', 'hybris', 'hylang', 'i6', 'i6t', 'i7', 'idl', 'idl4', 'idr', 'idris', 'iex', 'igor', 'igorpro',
        'ik', 'inform6', 'inform7', 'ini', 'io', 'ioke', 'ipython', 'ipython2', 'ipython3', 'ipythonconsole', 'irb',
        'irc', 'isabelle', 'j', 'jade', 'jags', 'jasmin', 'jasminxt', 'java', 'javascript', 'javascript+cheetah',
        'javascript+django', 'javascript+erb', 'javascript+genshi', 'javascript+genshitext', 'javascript+jinja',
        'javascript+lasso', 'javascript+mako', 'javascript+mozpreproc', 'javascript+myghty', 'javascript+php',
        'javascript+ruby', 'javascript+smarty', 'javascript+spitfire', 'jbst', 'jcl', 'jinja', 'jl', 'jlcon',
        'jproperties', 'js', 'js+cheetah', 'js+django', 'js+erb', 'js+genshi', 'js+genshitext', 'js+jinja', 'js+lasso',
        'js+mako', 'js+myghty', 'js+php', 'js+ruby', 'js+smarty', 'js+spitfire', 'json', 'json-ld', 'jsonld',
        'jsonml+bst', 'jsp', 'julia', 'kal', 'kconfig', 'kernel-config', 'kid', 'koka', 'kotlin', 'ksh', 'lagda',
        'lasso', 'lassoscript', 'latex', 'lcry', 'lcryptol', 'lean', 'less', 'lhaskell', 'lhs', 'lid', 'lidr', 'lidris',
        'lighttpd', 'lighty', 'limbo', 'linux-config', 'liquid', 'lisp', 'literate-agda', 'literate-cryptol',
        'literate-haskell', 'literate-idris', 'live-script', 'livescript', 'llvm', 'logos', 'logtalk', 'lsl', 'lua', 'm2',
        'make', 'makefile', 'mako', 'man', 'maql', 'mask', 'mason', 'mathematica', 'matlab', 'matlabsession', 'mawk',
        'menuconfig', 'mf', 'minid', 'mma', 'modelica', 'modula2', 'moin', 'monkey', 'moo', 'moocode', 'moon',
        'moonscript', 'mozhashpreproc', 'mozpercentpreproc', 'mq4', 'mq5', 'mql', 'mql4', 'mql5', 'msc', 'mscgen',
        'mupad', 'mxml', 'myghty', 'mysql', 'nasm', 'nawk', 'nb', 'nemerle', 'nesc', 'newlisp', 'newspeak', 'nginx',
        'nim', 'nimrod', 'nit', 'nix', 'nixos', 'nroff', 'nsh', 'nsi', 'nsis', 'numpy', 'obj-c', 'obj-c++', 'obj-j',
        'objc', 'objc++', 'objdump', 'objdump-nasm', 'objective-c', 'objective-c++', 'objective-j', 'objectivec',
        'objectivec++', 'objectivej', 'objectpascal', 'objj', 'ocaml', 'octave', 'odin', 'ooc', 'opa', 'openbugs',
        'openedge', 'pacmanconf', 'pan', 'parasail', 'pas', 'pascal', 'pawn', 'pcmk', 'perl', 'perl6', 'php', 'php3',
        'php4', 'php5', 'pig', 'pike', 'pkgconfig', 'pl', 'pl6', 'plpgsql', 'po', 'posh', 'postgres', 'postgres-console',
        'postgresql', 'postgresql-console', 'postscr', 'postscript', 'pot', 'pov', 'powershell', 'praat', 'progress',
        'prolog', 'properties', 'proto', 'protobuf', 'ps1', 'ps1con', 'psm1', 'psql', 'puppet', 'py', 'py3', 'py3tb',
        'pycon', 'pypy', 'pypylog', 'pyrex', 'pytb', 'python', 'python3', 'pyx', 'qbasic', 'qbs', 'qml', 'qvt', 'qvto',
        'r', 'racket', 'ragel', 'ragel-c', 'ragel-cpp', 'ragel-d', 'ragel-em', 'ragel-java', 'ragel-objc', 'ragel-rb',
        'ragel-ruby', 'raw', 'rb', 'rbcon', 'rconsole', 'rd', 'rebol', 'red', 'red/system', 'redcode', 'registry',
        'resource', 'resourcebundle', 'rest', 'restructuredtext', 'rexx', 'rhtml', 'rkt', 'roboconf-graph',
        'roboconf-instances', 'robotframework', 'rout', 'rql', 'rsl', 'rst', 'rts', 'ruby', 'rust', 's', 'sage', 'salt',
        'sass', 'sc', 'scala', 'scaml', 'scheme', 'scilab', 'scm', 'scss', 'sh', 'shell', 'shell-session', 'shen', 'slim',
        'sls', 'smali', 'smalltalk', 'smarty', 'sml', 'snobol', 'sources.list', 'sourceslist', 'sp', 'sparql', 'spec',
        'spitfire', 'splus', 'sql', 'sqlite3', 'squeak', 'squid', 'squid.conf', 'squidconf', 'ssp', 'st', 'stan',
        'supercollider', 'sv', 'swift', 'swig', 'systemverilog', 'tads3', 'tap', 'tcl', 'tcsh', 'tcshcon', 'tea',
        'termcap', 'terminfo', 'terraform', 'tex', 'text', 'tf', 'thrift', 'todotxt', 'trac-wiki', 'trafficscript',
        'treetop', 'ts', 'turtle', 'twig', 'typescript', 'udiff', 'urbiscript', 'v', 'vala', 'vapi', 'vb.net', 'vbnet',
        'vctreestatus', 'velocity', 'verilog', 'vfp', 'vgl', 'vhdl', 'vim', 'winbatch', 'winbugs', 'x10', 'xbase', 'xml',
        'xml+cheetah', 'xml+django', 'xml+erb', 'xml+evoque', 'xml+genshi', 'xml+jinja', 'xml+kid', 'xml+lasso',
        'xml+mako', 'xml+myghty', 'xml+php', 'xml+ruby', 'xml+smarty', 'xml+spitfire', 'xml+velocity', 'xq', 'xql', 'xqm',
        'xquery', 'xqy', 'xslt', 'xten', 'xtend', 'xul+mozpreproc', 'yaml', 'yaml+jinja', 'zephir',
    ],
);

#-------------------------------------------------------------------------------
# Global Variables
#-------------------------------------------------------------------------------

# 笔记的处理指令
my @ALL_NOTE_DIRECTIVES;

# 笔记内容的树状结构
# [
#     { # 顶级元素
#         type => 类型,
#         content => [ 一行或多行笔记文本 ],
#         children => [ 次级元素集合 ]
#     },
#     ...
# ]
my @ALL_NOTE_CONTENTS;

# 笔记的解析上下文
# [
#    $ALL_NOTE_CONTENTS->[0],                  # 顶级内容的指针
#    $ALL_NOTE_CONTENTS->[0]->{children}->[x], # 次级内容的指针
#    ...
# ]
my $CURR_PARSE_CONTEXT = [];

#-------------------------------------------------------------------------------
# TEST
#-------------------------------------------------------------------------------

#exit;

#-------------------------------------------------------------------------------
# INIT
#-------------------------------------------------------------------------------

init_env();

#-------------------------------------------------------------------------------
# MAIN
#-------------------------------------------------------------------------------

check_args(2, 7, '<note_file>', '<result_file>', '[output_format(-)]', '[debug_flag(-)]', '[max_title_level(-)]', '[max_subtitle_level(-)]', '[max_fold_depth(-)]');

# get program arguments
my $NOTE_FILE   = my_decode($ARGV[0]);
my $RESULT_FILE = my_decode($ARGV[1]);

$CONF{OUTPUT_FORMAT}      =  $ARGV[2]      if ($ARGV[2] and $ARGV[2] ne '-');
$CONF{DEBUG}              = ($ARGV[3] + 0) if ($ARGV[3] and $ARGV[3] ne '-');
$CONF{MAX_TITLE_LEVEL}    = ($ARGV[4] + 0) if ($ARGV[4] and $ARGV[4] ne '-');
$CONF{MAX_SUBTITLE_LEVEL} = ($ARGV[5] + 0) if ($ARGV[5] and $ARGV[5] ne '-');
$CONF{MAX_FOLD_DEPTH}     = ($ARGV[6] + 0) if ($ARGV[6] and $ARGV[6] ne '-');

# 创建维基笔记页面
parse_note_file();
write_result_file();

#-------------------------------------------------------------------------------
# PARSE

# 读取笔记文件内容, 调用parse_note_line()解析各行内容; DEBUG=TRUE则打印调试信息
sub parse_note_file
{
    my $note_file = open_input_file($NOTE_FILE);

    my $line_no = 1;
    while (<$note_file>)
    {
        chomp;
        parse_note_line($line_no ++, $_);
    }

    close $note_file;

    # debug
    if ($CONF{DEBUG})
    {
        println("DIRECTIVES: @ALL_NOTE_DIRECTIVES");

        foreach (@ALL_NOTE_CONTENTS)
        {
            prints(dump_element($_, 0)); # NOTE: dump_element()已经加回车, 所以不用println()
        }
    }
}

# 解析一行笔记文本
# @line_no   = 行号
# @line_text = 文本
# @RETURN = 所有指令写入ALL_NOTE_DIRECTIVES数组, 调用add_parsed_line()生成解析结果
sub parse_note_line
{
    my ($line_no, $line_text) = @_;

    # debug
    # println("$line_no: '$line_text'") if $CONF{DEBUG};

    my ($indent, $content) = $line_text =~ /^(\s*)(.*?)\s*$/;
    my $level = POSIX::floor(length($indent) / $CONF{INDENT_WIDTH});

    # debug
    # println("> level = $level, indent = '$indent', content = '$content'") if $CONF{DEBUG};

    my ($parsed_level, $parsed_type, $parsed_content) = (-1, ET_RETURN, '?');
    my $last_context_level = $#{ $CURR_PARSE_CONTEXT };
    my $last_context_type = $last_context_level >= 0 ? $CURR_PARSE_CONTEXT->[-1]->{type} : ET_RETURN;

    # debug
    # println("last_context_level = $last_context_level, last_context_type = $last_context_type") if $CONF{DEBUG};

    # 特殊指令(__DBG__,__TOC__, __END__)
    if (string_in_array($content, '__DBG__', '__TOC__', '__END__'))
    {
        push @ALL_NOTE_DIRECTIVES, $content;
        return;
    }
    # 笔记标签(@keys:x,y,z 或 @tags:x,y,z)
    if ($content =~ /^\@(keys|keywords?|tags?):\s*(.*)$/i)
    {
        push @ALL_NOTE_DIRECTIVES, split(/,/, $2);
        return;
    }

    # 代码块(@code:)
    if (check_group_type($line_no, $line_text, $level, $content, ET_CODE, "code"))
    {
        return;
    }
    # 表格块(@table:)
    if (check_group_type($line_no, $line_text, $level, $content, ET_TABLE, "table"))
    {
        return;
    }
    # 维基文本块(@raw:)
    if (check_group_type($line_no, $line_text, $level, $content, ET_RAWTEXT, "raw") or
        check_group_type($line_no, $line_text, $level, $content, ET_RAWTEXT, "wiki") or
        check_group_type($line_no, $line_text, $level, $content, ET_RAWTEXT, "rawtext") or
        check_group_type($line_no, $line_text, $level, $content, ET_RAWTEXT, "wikitext"))
    {
        return;
    }

    # 回车
    if ($content eq '')
    {
        $parsed_level = $last_context_level;
        $parsed_type = $last_context_type;
        $parsed_content = '';
    }
    # 标题(以+ 开头)?
    elsif ($content =~ /^\+\s+(.*)$/)
    {
        if ($level < $CONF{MAX_TITLE_LEVEL})
        {
            # 主标题
            $parsed_level = $level;
            $parsed_type = ET_TITLE;
            $parsed_content = $1;
        }
        elsif ($level < $CONF{MAX_TITLE_LEVEL} + $CONF{MAX_SUBTITLE_LEVEL})
        {
            # 子标题
            $parsed_level = $level;
            $parsed_type = ET_SUBTITLE;
            $parsed_content = $1;
        }
        else
        {
            # 标题 -> 正文
            # NOTE: 同一主标题或子标题下属的正文同级
            $parsed_level = $CONF{MAX_TITLE_LEVEL} + $CONF{MAX_SUBTITLE_LEVEL};
            $parsed_type = ET_TEXT;
            $parsed_content = ltrim($line_text, $parsed_level * $CONF{INDENT_WIDTH});
        }
    }
    # 单行原始文本(`xxx)
    elsif ($content =~ /^`(.*)$/)
    {
        $parsed_level = $level;
        $parsed_type = ET_RAWTEXT;
        $parsed_content = $1;
    }
    # 单行命令($ xxx)
    elsif ($content =~ /^\$\s+(.*)$/)
    {
        $parsed_level = $level;
        $parsed_type = ET_COMMAND;
        $parsed_content = $1;
    }
    # 其它
    else
    {
        # 命令的首行附属代码
        if ($last_context_type eq ET_COMMAND and $last_context_level < $level)
        {
            $parsed_level = $last_context_level;
            $parsed_type = ET_CODE;
            $parsed_content = ltrim($line_text, ($parsed_level + 1) * $CONF{INDENT_WIDTH}); # 书写缩进, 显示平级

            # 手工补充附属代码的首行信息
            add_parsed_line($parsed_level, $parsed_type, get_code_lang($CURR_PARSE_CONTEXT->[-1]->{content}->[-1]));
        }
        # NOTE: 命令的次行以后附属代码由check_group_type(ET_CODE)处理
        # ...
        # 普通文本
        else
        {
            $parsed_level = $level;
            $parsed_type = ET_TEXT;
            $parsed_content = ltrim($line_text, $parsed_level * $CONF{INDENT_WIDTH});
        }
    }

    add_parsed_line($parsed_level, $parsed_type, $parsed_content);
}

# 检查同类行
sub check_group_type
{
    my ($line_no, $line_text, $level, $content, $check_type, $check_tag) = @_;

    my ($parsed_level, $parsed_type, $parsed_content) = (-1, ET_RETURN, '?');
    my $last_context_level = $#{ $CURR_PARSE_CONTEXT };
    my $last_context_type = $last_context_level >= 0 ? $CURR_PARSE_CONTEXT->[-1]->{type} : ET_RETURN;

    if ($content =~ /^\@$check_tag:?\s*(.*)$/i)
    {
        # 匹配检查标记
        $parsed_level = $level;
        $parsed_type = $check_type;
        $parsed_content = $1;

        add_parsed_line($parsed_level, $parsed_type, $parsed_content);

        return 1;
    }

    if ($last_context_type eq $check_type and $last_context_level < $level)
    {
        # 前行内容是检查类型 + 前行级别<本行级别
        $parsed_level = $last_context_level;
        $parsed_type = $check_type;
        $parsed_content = ltrim($line_text, ($parsed_level + 1) * $CONF{INDENT_WIDTH}); # 书写缩进, 显示平级

        add_parsed_line($parsed_level, $parsed_type, $parsed_content);

        return 1;
    }

    return 0;
}

# 生成解析结果, 写入CURR_PARSE_CONTEXT数组
sub add_parsed_line
{
    my ($parsed_level, $parsed_type, $parsed_content) = @_;

    # debug
    # println("+ add_parsed_line($parsed_level, $parsed_type, '$parsed_content')") if $CONF{DEBUG};

    my $parent_element;
    my $max_context_level = $#{$CURR_PARSE_CONTEXT};

    for (my $i = 0; $i <= max($max_context_level, $parsed_level); ++ $i)
    {
        if ($i < $parsed_level)
        {
            if ($CURR_PARSE_CONTEXT->[$i])
            {
                # 上级内容已存在, 无须创建
            }
            else
            {
                # 上级内容不存在, 手工创建 -> NEW  (这种情况属于笔记缺陷, 应该返回修改)
                if ($i < $CONF{MAX_TITLE_LEVEL})
                {
                    $CURR_PARSE_CONTEXT->[$i] = { type => ET_TITLE, content => ['(未定义主标题)'], children => [] };
                }
                elsif ($i < $CONF{MAX_SUBTITLE_LEVEL})
                {
                    $CURR_PARSE_CONTEXT->[$i] = { type => ET_SUBTITLE, content => ['(未定义子标题)'], children => [] };
                }
                else
                {
                    $CURR_PARSE_CONTEXT->[$i] = { type => ET_TEXT, content => ['(未定义正文)'], children => [] };
                }

                # debug
                # println("    + adding PARENT to context: " . get_context_entry($i)) if $CONF{DEBUG};

                # 加入父级内容的下属集合
                if ($parent_element)
                {
                    push @{ $parent_element->{children} }, $CURR_PARSE_CONTEXT->[$i];
                }
                else
                {
                    if ($i == 0)
                    {
                        push @ALL_NOTE_CONTENTS, $CURR_PARSE_CONTEXT->[$i];
                    }
                    else
                    {
                        die "Logic Error: i = $i";
                    }
                }
            }
        }
        elsif ($i == $parsed_level)
        {
            if ($CURR_PARSE_CONTEXT->[$i] and ($CURR_PARSE_CONTEXT->[$i]->{type} eq $parsed_type) and (@{ $CURR_PARSE_CONTEXT->[$i]->{children} } == 0))
            {
                # 兄级内容已存在 + 类型相同 + 无下属内容: 融入兄级内容
                push @{ $CURR_PARSE_CONTEXT->[$i]->{content} }, $parsed_content;
            }
            else
            {
                # 兄级内容不存在 / 类型不同 / 有下属内容: 创建弟级内容 -> NEW
                $CURR_PARSE_CONTEXT->[$i] = { type => $parsed_type, content => [$parsed_content], children => [] };

                # debug
                # println("    + adding RECORD to context: " . get_context_entry($i)) if $CONF{DEBUG};

                # 加入父级内容的下属集合
                if ($parent_element)
                {
                    push @{ $parent_element->{children} }, $CURR_PARSE_CONTEXT->[$i];
                }
                else
                {
                    if ($i == 0)
                    {
                        push @ALL_NOTE_CONTENTS, $CURR_PARSE_CONTEXT->[$i];
                    }
                    else
                    {
                        die "Logic Error: i = $i";
                    }
                }
            }
        }
        else
        {
            # 清空下级内容
            pop @{ $CURR_PARSE_CONTEXT }; # NOTE: 删除顺序相反, 但是pop总数=删除总数
        }

        $parent_element = $CURR_PARSE_CONTEXT->[$i];
    }

    # debug
    # println('    ' . get_parse_context()) if $CONF{DEBUG};
}

# 获取语言种类
sub get_code_lang
{
    my $command_content = shift;

    if ($command_content =~ /# lang=(.+)$/i)
    {
        my $code_lang = lc $1;
        return nvl($EXT_TO_LANG{$code_lang}, $code_lang);
    }

    if ($command_content =~ /(vi|vim|EDIT).*\.([^\.\s]+)( # .*)?$/)
    {
        my $file_ext = lc $2;
        return nvl($EXT_TO_LANG{$file_ext}, $file_ext);
    }

    return '';
}

# 生成当前解析上下文(调试用)
sub get_parse_context
{
    my $result = "=== CURR_PARSE_CONTEXT ===\n";

    my $context_level = 0;
    foreach my $r(@{ $CURR_PARSE_CONTEXT })
    {
        $result .= '    ' . get_context_entry($context_level ++) . "\n";
    }

    return $result;
}

# 生成当前解析上下文的记录内容(调试用)
sub get_context_entry
{
    my $context_level = shift;

    my $r = $CURR_PARSE_CONTEXT->[$context_level];

    my $type = rtrim($r->{type});
    my $content = join ',', map { "'$_'"} @{ $r->{content} };
    my $children = scalar @{ $r->{children} };

    return "[$context_level] TYPE = $type, CONTENT = [$content], CHILDREN = [$children]";
}

# 生成区块调试信息(递归函数)
# @element = 区块定义
# @level   = 缩进级数
# @RETURN = 调试信息
sub dump_element
{
    my ($element, $level) = @_;

    my $result_text = '';

    foreach (@{ $element->{content} })
    {
        $result_text .= $CONF{INDENT_STRING} x $level . "[$element->{type}] $_" . "\n";
    }

    foreach (@{ $element->{children} })
    {
        $result_text .= dump_element($_, $level + 1);
    }

    return $result_text;
}

#-------------------------------------------------------------------------------
# OUTPUT

# 将转换结果写入结果文件
sub write_result_file
{
    # 1.页头
    my $begin = output_begin();
    $begin = rtrim($begin);

    # 2.页体
    my $body;
    foreach (@ALL_NOTE_CONTENTS)
    {
        $body .= output_element($_, 0);
    }
    $body = rtrim($body);

    # 3.页尾
    my $end = output_end();
    $end = rtrim($end);

    # ALL
    my $output_text = ($begin ? $begin . "\n\n" : ''). ($body ? $body . "\n\n" : '') . ($end . "\n\n");

    # TOC
    if (!string_in_array('__TOC__', @ALL_NOTE_DIRECTIVES))
    {
        my $titles = 0;
        foreach (@ALL_NOTE_CONTENTS)
        {
            if ($_->{type} eq ET_TITLE)
            {
                $titles ++;
            }
        }
        if ($titles >= 3)
        {
            $output_text = "__TOC__\n\n" . $output_text;
        }
    }

    # __NOEDITSECTION__
    $output_text .= "__NOEDITSECTION__\n\n";

    # DBG
    if (string_in_array('__DBG__', @ALL_NOTE_DIRECTIVES))
    {
        my $input_code = load_file($NOTE_FILE);

        $input_code =~ s/</&lt;/g;
        $input_code =~ s/>/&gt;/g;

        my $output_code = $output_text;

        $output_code =~ s/</&lt;/g;
        $output_code =~ s/>/&gt;/g;

        # NOTE: 实测geshi不转换html-entity
        $output_text .= <<EOT
==调试信息==
===笔记文本===
<div class="mw-collapsible mw-collapsed">
<source lang="html">
$input_code
</source>
</div>
===维基代码===
<div class="mw-collapsible mw-collapsed">
<source lang="html">
$output_code
</source>
</div>
EOT
    }

    # 写入文件
    my $result_file = open_output_file($RESULT_FILE);
    print $result_file $output_text;
    close $result_file;
}

# 生成页首内容
# NOTE: 通过动态特性支持不同转换格式
sub output_begin
{
    return &{\&{ $CONF{OUTPUT_FORMAT} . "_begin" }}(); # 语法请参考: perldoc strict
}

# 生成页尾内容
# NOTE: 通过动态特性支持不同转换格式
sub output_end
{
    return &{\&{ $CONF{OUTPUT_FORMAT} . "_end" }}(); # 语法请参考: perldoc strict
}

# 生成区块内容
# NOTE: 通过动态特性支持不同转换格式
sub output_element
{
    my ($element, $level) = @_;

    my $result_text = '';

    # OPEN
    $result_text .= &{\&{ $CONF{OUTPUT_FORMAT} . '_' . lc(trim($element->{type})) }}(1, $element->{content}, $level); # 语法请参考: perldoc strict

    # CHILDREN
    foreach (@{ $element->{children} })
    {
        $result_text .= output_element($_, $level + 1);
    }

    # CLOSE
    $result_text .= &{\&{ $CONF{OUTPUT_FORMAT} . '_' . lc(trim($element->{type})) }}(0, $element->{content}, $level); # 语法请参考: perldoc strict

    return $result_text;
}

#-------------------------------------------------------------------------------
# MediaWiki

# 转换文首
# @RETURN = 转换后的文本, 如: __TOC__
sub MediaWiki_begin
{
    my $wikitext = '';

    # 目录
    if (string_in_array('__TOC__', @ALL_NOTE_DIRECTIVES))
    {
        $wikitext .= "__TOC__\n";
    }

    return $wikitext;
}

# 转换文尾
# @RETURN = 转换后的文尾, 如: {{自动笔记页尾}}
sub MediaWiki_end
{
    my $wikitext = '';

    # 页尾跳转
    if (string_in_array('__END__', @ALL_NOTE_DIRECTIVES))
    {
        $wikitext .= "{{自动笔记页尾}}\n";
    }

    # 页面标注
    foreach (@ALL_NOTE_DIRECTIVES)
    {
        unless (string_in_array($_, '__DBG__', '__TOC__', '__END__'))
        {
            if ($_ =~ /\[\[分类:(.*)\]\]/) # 兼容老格式
            {
                $wikitext .= "$_\n";
            }
            else
            {
                $wikitext .= "[[分类:$_]]\n";
            }
        }
    }

    return $wikitext;
}

# 转换回车
# @open_flag  = T:开放标签(如:<div>), F:闭合标签(如:</div>)
# @r_contents = 转换文本的行数组引用(保留)
# @level      = 缩进级数(保留)
# @RETURN = 转换后的回车(\n)
sub MediaWiki_return
{
    my ($open_flag, $r_contents, $level) = @_;

    my $wikitext = '';

    if ($open_flag)
    {
        $wikitext .= "\n";
    }

    return $wikitext;
}

# 转换主标题
# @open_flag  = T:开放标签(如:<div>), F:闭合标签(如:</div>)
# @r_contents = 转换文本的行数组引用(只有1行)
# @level      = 缩进级数
# @RETURN = 转换后的主标题(维基章节)
sub MediaWiki_title
{
    my ($open_flag, $r_contents, $level) = @_;

    my $wikitext = '';

    # NOTE: 无下属内容的主标题自动合并
    foreach my $title_text(@{ $r_contents })
    {
        if ($open_flag)
        {
            # 维基章节
            my $title_tag = '=' x ($level + 2);
            $wikitext .= $title_tag . $title_text . $title_tag . "\n";

            # 折叠区块
            if ($level < $CONF{MAX_FOLD_DEPTH})
            {
                $wikitext .= "<div class=\"mw-collapsible\">\n";
            }
        }
        else
        {
            # 折叠区块
            if ($level < $CONF{MAX_FOLD_DEPTH})
            {
                $wikitext .= "</div>\n";
            }
        }
    }

    return $wikitext;
}

# 转换子标题
# @open_flag  = T:开放标签(如:<div>), F:闭合标签(如:</div>)
# @r_contents = 转换文本的行数组引用(只有1行)
# @level      = 缩进级数
# @RETURN = 转换后的子标题(缩进无序列表)
sub MediaWiki_subtitle
{
    my ($open_flag, $r_contents, $level) = @_;

    my $wikitext = '';

    # NOTE: 无下属内容的子标题自动合并
    foreach my $subtitle_text(@{ $r_contents })
    {
        if ($open_flag)
        {
            # 缩进无序列表
            my $subtitle_tag = ':' x ($level - $CONF{MAX_TITLE_LEVEL}) . '* ';
            $wikitext .= $subtitle_tag . $subtitle_text . "\n";
        }
    }

    return $wikitext;
}

# 转换命令文本
# @open_flag  = T:开放标签(如:<div>), F:闭合标签(如:</div>)
# @r_contents = 转换文本的行数组引用
# @level      = 缩进级数
# @RETURN = 转换后的多行命令文本
sub MediaWiki_command
{
    my ($open_flag, $r_contents, $level) = @_;

    my $wikitext = '';

    if ($open_flag)
    {
        my $indent = $level > 0 ? max($level > $CONF{MAX_TITLE_LEVEL} ? $level - $CONF{MAX_TITLE_LEVEL} - 1
                                                                      : $level - $CONF{MAX_TITLE_LEVEL}, 0) + 1
                                : 0;

        $wikitext .= "<geshi lang=\"bash\" class=\"geshi_cmd_text indent_$indent\">\n";

        foreach (@{ $r_contents })
        {
            $wikitext .= "$_\n";
        }

        $wikitext .= "</geshi>\n";
    }

    return $wikitext;
}

# 转换代码文本
# @open_flag  = T:开放标签(如:<div>), F:闭合标签(如:</div>)
# @r_contents = 转换文本的行数组引用
# @level      = 缩进级数
# @RETURN = 转换后的多行代码文本
sub MediaWiki_code
{
    my ($open_flag, $r_contents, $level) = @_;

    my $wikitext = '';

    my $code_lang = shift @{ $r_contents }; # code的首行是语种
    my $code_tag = MediaWiki_get_codetag($code_lang, $r_contents->[0]);

    if ($open_flag)
    {
        my $indent = $level > 0 ? max($level > $CONF{MAX_TITLE_LEVEL} ? $level - $CONF{MAX_TITLE_LEVEL} - 1
                                                                      : $level - $CONF{MAX_TITLE_LEVEL}, 0) + 1
                                : 0;

        # debug
        # println("first code line = $r_contents->[0]");

        my $collapse_classes = '';

        if ($r_contents->[0] eq '@+')
        {
            shift @{ $r_contents };
            $collapse_classes = ' mw-collapsible mw-collapsed';
        }
        elsif ($r_contents->[0] eq '@-')
        {
            shift @{ $r_contents };
            $collapse_classes = ' mw-collapsible';
        }
        else
        {
            # 目前source不支持代码折叠
            if ($code_tag ne 'source' and @{ $r_contents} >= $CONF{MIN_COLLAPSE_LINES})
            {
                $collapse_classes = ' mw-collapsible mw-collapsed';
            }
        }

        if ($code_tag eq 'source')
        {
            $wikitext .= "<source lang=\"$code_lang\" class-name=\"source_code_text indent_$indent $collapse_classes\">\n";
        }
        elsif ($code_tag eq 'geshi')
        {
            $wikitext .= "<geshi lang=\"$code_lang\" class=\"geshi_code_text indent_$indent $collapse_classes\">\n";
        }
        else
        {
            $wikitext .= "<$code_tag class=\"other_code_text indent_$indent $collapse_classes\">\n"; # 目前符合条件的$code_tag只有<pre>
        }

        foreach (@{ $r_contents })
        {
            # 替换<pre>和</pre>(<>转换html实体), 防止代码中的<pre>和</pre>破坏GROUP标记<pre>
            s/<($code_tag)>/&lt;$1&gt;/g;
            s/<\/($code_tag)>/&lt;\/$1&gt;/g;

            $wikitext .= "$_\n";
        }

        $wikitext .= "</$code_tag>\n";
    }

    return $wikitext;
}

# 转换表格文本
# @open_flag  = T:开放标签(如:<div>), F:闭合标签(如:</div>)
# @r_contents = 转换文本的行数组引用
# @level      = 缩进级数
# @RETURN = 转换后的多行表格文本
sub MediaWiki_table
{
    my ($open_flag, $r_contents, $level) = @_;

    my $wikitext = '';

    if ($open_flag)
    {
        my $indent = $level > 0 ? max($level > $CONF{MAX_TITLE_LEVEL} ? $level - $CONF{MAX_TITLE_LEVEL} - 1
                                                                      : $level - $CONF{MAX_TITLE_LEVEL}, 0) + 1
                                : 0;

        # table的首行是class
        my $table_class = shift @{ $r_contents };

        # class末尾的连续>>>表示额外缩进级数
        if ($table_class =~ s/\s*(>+)$//)
        {
            $indent += length $1;
        }

        # class缺省是wiki_table
        $table_class = 'wiki_table' unless $table_class;

        $wikitext .= "{| class=\"$table_class indent_$indent\"\n";

        foreach my $row_content(@{ $r_contents })
        {
            $wikitext .= "|-\n";

            # 特殊处理: K = V 两列(K中没有|)
            if ($row_content =~ /^([^\|]+?)\s+=\s+(.*)$/)
            {
                my $K_text = nvl(MediaWiki_conversion($1), '&nbsp;');
                my $V_text = nvl(MediaWiki_conversion($2), '&nbsp;');

                $K_text =~ s/\|/<nowiki>\|<\/nowiki>/g;
                $V_text =~ s/\|/<nowiki>\|<\/nowiki>/g;

                $wikitext .= "! $K_text\n";
                $wikitext .= "| $V_text\n";
            }
            # 特殊处理: --- 通栏跨列
            elsif ($row_content =~ /^-{3,}$/)
            {
                $wikitext .= "| colspan=999 | &nbsp;\n";
            }
            else
            {
                # debug
                # println("table row = $row_content");

                # 各列以'|'或'~'分隔
                foreach my $cell_content(split /\s+[\|\~]\s+/, $row_content)
                {
                    # debug
                    # println("cell_content = $cell_content");

                    $cell_content = trim($cell_content);

                    # 忽略空单元方便跨行跨 -> 空白单元应填类似&nbsp;文本
                    next unless $cell_content;

                    # 单元定义 = 内容[跨列数x跨行数]?{样式}?
                    my ($cell_text, $cell_colspan, $cell_rowspan, $cell_style) = ($cell_content =~ /^(.*?)(\[(\d*)[Xx](\d*)?\])?(\{([^\{].*?[^\}])\})?$/)[0,2,3,5];

                    $cell_text    = '' unless $cell_text;
                    $cell_style   = '' unless $cell_style;
                    $cell_colspan = '' unless $cell_colspan;
                    $cell_rowspan = '' unless $cell_rowspan;

                    # debug
                    # println("'$cell_content': cell_text='$cell_text', cell_style='$cell_style', cell_colspan='$cell_colspan', cell_rowspan='$cell_rowspan'") if $CONF{DEBUG};

                    # 数字右对齐
                    my @cell_styles = split /\s*;\s*/, $cell_style;

                    if ($cell_text =~ /^[\+\-]?\d+(\.\d*)?$/ and $cell_style !~ /\btext-align\b/)
                    {
                        push @cell_styles, "text-align:right";
                    }

                    $cell_style = join ';', @cell_styles;

                    # *表头*被星号包围 OR !表头带感叹号前缀
                    if ($cell_text =~ /^\*(.*)\*$/ or $cell_text =~ /^!(.*)$/)
                    {
                        $wikitext .= "! ";
                        $cell_text = $1;
                    }
                    else
                    {
                        $wikitext .= "| ";
                    }

                    # 生成样式
                    if ($cell_style or $cell_colspan or $cell_rowspan)
                    {
                        if ($cell_style)
                        {
                            $wikitext .= "style=\"$cell_style\" ";
                        }
                        if ($cell_colspan)
                        {
                            $wikitext .= "colspan=$cell_colspan ";
                        }
                        if ($cell_rowspan)
                        {
                            $wikitext .= "rowspan=$cell_rowspan ";
                        }
                        $wikitext .= " | ";
                    }

                    # 生成内容
                    $wikitext .= MediaWiki_conversion($cell_text) . "\n";
                }
            }
        }

        $wikitext .= "|}\n";
    }

    return $wikitext;
}

# 转换原始文本
# @open_flag  = T:开放标签(如:<div>), F:闭合标签(如:</div>)
# @r_contents = 转换文本的行数组引用
# @level      = 缩进级数(保留)
# @RETURN = 转换后的多行原始文本
sub MediaWiki_rawtext
{
    my ($open_flag, $r_contents, $level) = @_;

    my $wikitext = '';

    if ($open_flag)
    {
        foreach (@{ $r_contents })
        {
            $wikitext .= "$_\n";
        }
    }

    return $wikitext;
}

# 转换笔记文本
# @open_flag  = T:开放标签(如:<div>), F:闭合标签(如:</div>)
# @r_contents = 转换文本的行数组引用
# @level      = 缩进级数
# @RETURN = 转换后的多行笔记文本
sub MediaWiki_text
{
    my ($open_flag, $r_contents, $level) = @_;

    my $wikitext = '';

    my $indent = $level > 0 ? max($level > $CONF{MAX_TITLE_LEVEL} ? $level - $CONF{MAX_TITLE_LEVEL} - 1
                                                                  : $level - $CONF{MAX_TITLE_LEVEL}, 0) + 1
                            : 0;

    if ($open_flag)
    {
        if ($indent > 0)
        {
            $wikitext .= "<div class=\"indent_$indent\">\n";
        }

        foreach (@{ $r_contents })
        {
            $wikitext .= MediaWiki_conversion($_) . "\n";
        }
    }
    else
    {
        if ($indent > 0)
        {
            $wikitext .= "</div>\n";
        }
    }

    return $wikitext;
}

# 处理自定义的语义标签
# @content = 单行原始输入
# @RETURN = 单行解析输出
sub MediaWiki_conversion
{
    my $content = shift;

    # 加粗: <*粗体*>
    # 斜体: </斜体/>
    # 下划: <_下划_>
    # 删除: <-删除->
    # 上标: <^上标^>
    # 下标: <.下标.>
    foreach (1..2)
    {
        # 混合上述格式时最多允许3种(2/3)
        $content =~ s/<([\*\/\_\-\^\.]+)\*(.*?)\*\1>/<b><$1$2$1><\/b>/g;
        $content =~ s/<([\*\/\_\-\^\.]+)\/(.*?)\/\1>/<i><$1$2$1><\/i>/g;
        $content =~ s/<([\*\/\_\-\^\.]+)\_(.*?)\_\1>/<u><$1$2$1><\/u>/g;
        $content =~ s/<([\*\/\_\-\^\.]+)\-(.*?)\-\1>/<del><$1$2$1><\/del>/g;
        $content =~ s/<([\*\/\_\-\^\.]+)\^(.*?)\^\1>/<sup><$1$2$1><\/sup>/g;
        $content =~ s/<([\*\/\_\-\^\.]+)\.(.*?)\.\1>/<sub><$1$2$1><\/sub>/g;
    }

    # 混合上述格式时最多允许3种(1/3)
    $content =~ s/<\*(.*?)\*>/<b>$1<\/b>/g;
    $content =~ s/<\/(.*?)\/>/<i>$1<\/i>/g;
    $content =~ s/<\_(.*?)\_>/<u>$1<\/u>/g;
    $content =~ s/<\-(.*?)\->/<del>$1<\/del>/g;
    $content =~ s/<\^(.*?)\^>/<sup>$1<\/sup>/g;
    $content =~ s/<\.(.*?)\.>/<sub>$1<\/sub>/g;

    # 参数: <%参数%>
    $content =~ s/<%(.*?)%>/<span class="note_variable">$1<\/span>/g;

    # 代码: <~代码~>
    $content =~ s/<~\s?(.*?)\s?~>/<code><nowiki>$1<\/nowiki><\/code>/g; # 允许前后加1个空格

    # 代码: <#代码#>
    $content =~ s/<#\s?(.*?)\s?#>/<code>$1<\/code>/g; # 允许前后加1个空格

    # 行尾注释: ' # '
    $content =~ s/(\S\s*) # (.*)$/$1 <span class="note_comment"># $2<\/span>/;

    # 单行注释: '@# '
    $content =~ s/^\@# (.*)$/<div class="note_comment"># $1<\/div>/;

    # 单行警告: '@WARN:'
    $content =~ s/^\@WARN:\s?(.*)$/<div class="note_warn">[[图像:note-warn.png|text-bottom|link=]] $1<\/div>/i;

    # 单行信息: '@INFO:' -> 兼容@NOTE:
    $content =~ s/^\@(?:INFO|NOTE):\s?(.*)$/<div class="note_info">[[图像:note-info.png|text-bottom|link=]] $1<\/div>/i;

    # 单行提示: '@HINT:'
    $content =~ s/^\@HINT:\s?(.*)$/<div class="note_hint">[[图像:note-hint.png|text-bottom|link=]] $1<\/div>/i;

    # 单行TODO: '@TODO:'
    $content =~ s/^\@TODO:\s?(.*)$/<div class="note_todo">[[图像:note-todo.png|text-bottom|link=]] $1<\/div>/i;

    # 单行参考: '@REF:'
    $content =~ s/^\@REF:\s?(.*)$/<div class="note_reference">[[图像:note-ref.png|text-bottom|link=]] $1<\/div>/i;

    # 行首符号: '->'转换为'→ '
    #           '=>'转换为'⇒ ' NOTE: 本字体无法显示, 实际为双杆箭头: &rArr;
    #           'o)'转换为'¤ '
    #           'O)'转换为'☼ '
    $content =~ s/^-> (.*)$/→ $1<br>/;
    $content =~ s/^=> (.*)$/⇒ $1<br>/;
    $content =~ s/^o (.*)$/¤ $1<br>/;
    $content =~ s/^O (.*)$/☼ $1<br>/;

    return $content;
}

# 获取包围代码的语法标签, 如: <source>, <geshi>, <pre>
# NOTE: 首选<source>但是支持语种少且不能折叠; 次选<geshi>但是不太好看; 末选<pre>以支持稀有语种
# @code_lang  = 语种, 如: c, perl, ...
# @first_line = 首行, 如: @+, @-, ...
# @RETURN = 代码标签, N选1: {source|geshi|pre}
sub MediaWiki_get_codetag
{
    my ($code_lang, $first_line) = @_;

    while (my ($plugin_tag, $support_langs) = each %ALL_SUPPORT_LANGS)
    {
        if (string_in_array($code_lang, @{ $support_langs }))
        {
            # 目前source不支持代码折叠
            if ($plugin_tag eq 'source')
            {
                if (string_in_array($first_line, '@+', '@-'))
                {
                    next;
                }
            };

            return $plugin_tag;
        }
    }

    return 'source'; # 缺省若用<pre>则样式难以与<source>和<geshi>统一
}
