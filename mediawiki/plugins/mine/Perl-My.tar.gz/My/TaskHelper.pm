
#-------------------------------------------------------------------------------
# Package Name
#-------------------------------------------------------------------------------

package My::TaskHelper;

#-------------------------------------------------------------------------------
# Comments
#-------------------------------------------------------------------------------

# 自动完成MediaWiki服务器的登录和注销, 并执行业务功能函数:
#   run_wiki_task($task_name, $passport, $r_task_func, @task_args);

#-------------------------------------------------------------------------------
# Compile Options
#-------------------------------------------------------------------------------

use strict;
use warnings;

#-------------------------------------------------------------------------------
# Import Modules
#-------------------------------------------------------------------------------

use utf8; # 文件内容是UTF8编码(utf8 flag = ON)

use Encode;
use File::Basename;
use My::Common;
use My::MediaWiki;

#-------------------------------------------------------------------------------
# Export Interface
#-------------------------------------------------------------------------------

require Exporter;

our (@ISA, @EXPORT, @EXPORT_OK);

# CLASS list
@ISA = qw(
    Exporter
);

# FUNCTION list
@EXPORT = qw(
    run_wiki_task
    create_wiki_template
);

# VARIABLE list
@EXPORT_OK = qw(
);

#-------------------------------------------------------------------------------
# Internal Constants
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# Internal Variables
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# Internal Functions
#-------------------------------------------------------------------------------

sub _init_task_env
{
    my $task_name = shift;

    my $log_file = $task_name . ".log";
    my $err_file = $task_name . ".err";

    unlink $log_file if -e $log_file;
    unlink $err_file if -e $err_file;
}

#-------------------------------------------------------------------------------
# Export Variables (@EXPORT_OK)
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# Export Functions (@EXPORT)
#-------------------------------------------------------------------------------

sub run_wiki_task
{
    my ($task_name, $passport, $r_task_func, @task_args) = @_;

    if ($passport =~ /^\d+$/)
    {
        my $predefined_envvar = 'WIKI_TOKEN_' . $passport;
        my $predefined_passport = $ENV{$predefined_envvar}
            or die my_encode("ERROR: 维基访问令牌 '$predefined_envvar' 未定义, 请定义环境变量 '$predefined_envvar', 格式为 'user:pass\@host/path'");
        $passport = $predefined_passport;
    }

    my $result = 0;

    # 0) Init
    _init_task_env($task_name);

    # 1) Login
    if (login($passport))
    {
        # 2) Do work
        $result = &{$r_task_func}(@task_args);

        # 3) Logout
        logout();
    }

    return $result;
}

sub create_wiki_template
{
    my ($template_name,
        $template_usage,
        $args_help,
        $args_example,
        $template_demo,
        $template_category,
        $related_object,
        $template_code,
        $user_category,
        $edit_note,
        $r_edit_feedback,
        $r_create_page_func,
        $cargo_table_declare,
        $cargo_table_store) = @_;

    # 预处理
    $template_usage    = '' unless $template_usage;
    $args_help         = '' unless $args_help;
    $args_example      = '' unless $args_example;
    $template_category = '' unless $template_category;

    $cargo_table_declare = '' unless $cargo_table_declare;
    $cargo_table_store   = '' unless $cargo_table_store;

    $args_help    = join "\n", map { "| $_" } split /~~|\n/, $args_help;
    $args_example = join "\n", map { "| $_" } split /~~|\n/, $args_example;

    # 组织内容
    my $page_name = "模板:$template_name";
    my $page_content = '';

    # -> noinclude部分
    $page_content .= "<noinclude>";

    $page_content .= "__TOC__\n";

    $page_content .= "\n==模板说明==\n";
    if ($template_name eq '模板说明')
    {
        $page_content .= "$template_usage\n";
    }
    else
    {
        $page_content .= "{{模板说明\n";
        $page_content .= "| 用途简介 = <pre>$template_usage</pre>\n";
        if (not $args_help and not $args_example)
        {
            $page_content .= "| 参数说明 = <pre>{{$template_name}}</pre>\n";
            $page_content .= "| 参数示例 = <pre>{{$template_name}}</pre>\n";
        }
        else
        {
            $page_content .= "| 参数说明 = <pre>{{$template_name\n$args_help\n}}</pre>\n";
            $page_content .= "| 参数示例 = <pre>{{$template_name\n$args_example\n}}</pre>\n";
        }
        $page_content .= "}}\n";
    }

    $page_content .= "\n==模板代码==\n";
    $page_content .= "<pre>\n";
    $page_content .= "$template_code\n";
    $page_content .= "</pre>\n";

    $page_content .= "[[分类:$template_category]]\n" if $template_category;
    $page_content .= "$cargo_table_declare\n" if $cargo_table_declare;
    $page_content .= "</noinclude>";

    # -> includeonly部分(NOTE:MediaWiki对\n很敏感, 需要时在代码首尾自行添加)
    $page_content .= "<includeonly>";
    $page_content .= "$template_code";
    $page_content .= "[[分类:$user_category]]" if $user_category;
    $page_content .= "$cargo_table_store\n" if $cargo_table_store;
    $page_content .= "</includeonly>";

    # 创建模板
    if ($r_create_page_func)
    {
        return $r_create_page_func->($page_name, $page_content, $edit_note, $r_edit_feedback);
    }
    else
    {
        return edit_page($page_name, $page_content, $edit_note, $r_edit_feedback);
    }
}

#-------------------------------------------------------------------------------
1;
