
#-------------------------------------------------------------------------------
# Package Name
#-------------------------------------------------------------------------------

package My::MediaWiki;

#-------------------------------------------------------------------------------
# Comments
#-------------------------------------------------------------------------------

# CALL below API functions:
# +  MediaWiki::API->new( $config_hashref )
# +  MediaWiki::API->login( $query_hashref )
# +  MediaWiki::API->api( $query_hashref, $options_hashref )
# +  MediaWiki::API->logout()
# +  MediaWiki::API->edit( $query_hashref, $options_hashref )
# +  MediaWiki::API->get_page( $params_hashref )
# +  MediaWiki::API->list( $query_hashref, $options_hashref )
# +  MediaWiki::API->upload( $params_hashref )
# +  MediaWiki::API->download( $params_hashref )

#-------------------------------------------------------------------------------
# Compile Options
#-------------------------------------------------------------------------------

use strict;
use warnings;

#-------------------------------------------------------------------------------
# Import Modules
#-------------------------------------------------------------------------------

use utf8; # 当前脚本是UTF8编码(utf8 flag = ON)

use Encode;
use MediaWiki::API;
use My::Common;

#-------------------------------------------------------------------------------
# Export Interface
#-------------------------------------------------------------------------------

require Exporter;

our (@ISA, @EXPORT, @EXPORT_OK);

# CLASS list
@ISA = qw(
    Exporter
);

# FUNCTION list
@EXPORT = qw(
    get_namespace_id
    get_namespace_name
    login
    logout
    info_page
    read_page
    edit_page
    move_page
    delete_page
    delete_page_r
    purge_page
    create_user
    block_user
    parse_page
    parse_text
    expand_text
    repair_wiki_url
    upload_file
    download_file
    query_users
    query_namespaces
    query_categories
    query_pages
    query_backlinks
    query_category_members
    query_category_members_r
    query_site_info
    query_base_url
    query_user_touch
    query_wiki_objects
);

# VARIABLE list
@EXPORT_OK = qw(
);

#-------------------------------------------------------------------------------
# Internal Constants
#-------------------------------------------------------------------------------

use constant {
    NS_MAIN            => 0,
    NS_TALK            => 1,
    NS_USER            => 2,
    NS_USER_TALK       => 3,
    NS_PROJECT         => 4,
    NS_PROJECT_TALK    => 5,
    NS_FILE            => 6,
    NS_FILE_TALK       => 7,
    NS_MEDIAWIKI       => 8,
    NS_MEDIAWIKI_TALK  => 9,
    NS_TEMPLATE        => 10,
    NS_TEMPLATE_TALK   => 11,
    NS_HELP            => 12,
    NS_HELP_TALK       => 13,
    NS_CATEGORY        => 14,
    NS_CATEGORY_TALK   => 15,
};

#-------------------------------------------------------------------------------
# Internal Variables
#-------------------------------------------------------------------------------

my $API;
my $WIKI_HOST;
my $WIKI_PATH;
my $WIKI_URL;

my %NS_ID2NAME;
my %NS_NAME2ID;

#-------------------------------------------------------------------------------
# Internal Functions
#-------------------------------------------------------------------------------

sub parse_passport
{
    my $passport = shift;

    # FORMAT: '<user:pass@host/path>'
    my ($user, $pass) = split /\:/, (split /\@/, $passport)[0];
    my ($host, $path) = split /\//, (split /\@/, $passport)[1];

    # decode special characters
    my %SPECIAL_URL_CHARS = (
        '%20' => ' ',
        '%22' => '"',
        '%23' => '#',
        '%25' => '%',
        '%26' => '&',
        '%28' => '(',
        '%29' => ')',
        '%2B' => '+',
        '%2C' => ',',
        '%2F' => '/',
        '%3A' => ':',
        '%3B' => ';',
        '%3C' => '<',
        '%3D' => '=',
        '%3E' => '>',
        '%3F' => '?',
        '%40' => '@',
        '%5C' => '\\',
        '%7C' => '|',
        );
    while (my ($code, $char) = each %SPECIAL_URL_CHARS)
    {
        $pass =~ s/$code/$char/g;
    }

    return ($host, $path, $user, $pass);
}

sub dump_result
{
    my $result = shift;

    return unless defined $result;

    println(dump_variable($result));
}

#-------------------------------------------------------------------------------
# Export Variables (@EXPORT_OK)
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# Export Functions (@EXPORT)
#-------------------------------------------------------------------------------

sub get_namespace_id
{
    my $ns_name = shift;

    return 0 if $ns_name eq '主'; # 如何传入空串参数?

    unless (%NS_ID2NAME)
    {
        my $r_namespaces = query_namespaces();
        while (my ($id, $r_data) = each %{ $r_namespaces })
        {
            my $name = $r_data->{'*'};;

            $NS_ID2NAME{$id} = $name;
            $NS_NAME2ID{$name} = $id;
        }
    }

    return $NS_NAME2ID{$ns_name};
}

sub get_namespace_name
{
    my $ns_id = shift;

    unless (%NS_ID2NAME)
    {
        my $r_namespaces = query_namespaces();
        while (my ($id, $r_data) = each %{ $r_namespaces })
        {
            my $name = $r_data->{'*'};;

            $NS_ID2NAME{$id} = $name;
            $NS_NAME2ID{$name} = $id;
        }
    }

    return $NS_ID2NAME{$ns_id};
}

sub login
{
    my ($wiki_host, $wiki_path, $wiki_user, $wiki_pass) = parse_passport(shift);

    # CALL MediaWiki::API->login():
    # REF: https://www.mediawiki.org/wiki/API:Login
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Elogin%28_$query_hashref_%29
    my $result = 0;

    # 1) Logout if already login
    if ($API)
    {
        $API->logout();
        $API = undef;
    }

    # 2) Initialize API object
    $API = new MediaWiki::API({
            api_url => "https://$wiki_host/$wiki_path/api.php",
            retries => 2,
            retry_delay => 1,
        });
    if (not $API)
    {
        warn my_encode("ERROR: failed to create MediaWiki:API object\n");
        return 0;
    }

    # 3) Login MediaWiki
    $result = $API->login({
            lgname     => $wiki_user,
            lgpassword => $wiki_pass,
            lgdomain   => 'local',
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to login 'https://$wiki_host/$wiki_path', API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to login 'https://$wiki_host/$wiki_path', API error = $result->{error}->{details}\n");
        return 0;
    }

    # 4) Save api URL and set upload URL
    my $site_info = query_site_info('general');
    $WIKI_HOST = $site_info->{server};      # https://192.168.0.1
    $WIKI_PATH = $site_info->{scriptpath};  # /wiki
    $WIKI_URL = $WIKI_HOST . $WIKI_PATH;    # https://192.168.0.1/wiki

    println("*** CONNECTED to $WIKI_URL/ ***\n"); # 追加空行隔开应用输出

    return 1;
}

sub logout
{
    # CALL MediaWiki::API->logout()
    # REF: https://www.mediawiki.org/wiki/API:Logout
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Elogout%28%29
    if ($API)
    {
        $API->logout();
        $API = undef;
        return 1;
    }

    return 0;
}

sub info_page
{
    my ($page_name, $allow_missing) = @_;

    # CALL MediaWiki::API->get_page()
    # REF: https://www.mediawiki.org/wiki/API:Query
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eget_page%28_$params_hashref_%29
    my $result = 0;

    # 1) Get page properties
    $result = $API->get_page({
            title => $page_name
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to read page '$page_name', API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to read page '$page_name', ACTION error = $result->{error}->{details}\n");
        return 0;
    }
    if (exists($result->{missing}))
    {
        if (not $allow_missing)
        {
            warn my_encode("ERROR: failed to read page '$page_name', ACTION error = page NOT found\n");
        }
        return 0;
    }

    # COMMON properties:
    #   '*' - contents of page
    #   'pageid' - page id of page
    #   'revid' - revision id of page
    #   'timestamp' - timestamp of revision
    #   'user' - user who made revision
    #   'title' - the title of the page
    #   'ns' - the namespace the page is in
    #   'size' - size of page in bytes

    # OK example:
    #   %{
    #       ns => 0
    #       title => 周京晖
    #       size => 119
    #       comment =>
    #       pageid => 173
    #       parentid => 13490
    #       revid => 13939
    #       contentmodel => wikitext
    #       contentformat => text/x-wiki
    #       user => 周京晖
    #       timestamp => 2015-07-04T13:18:05Z
    #       * => {{世轩用户
    #            |姓名=周京晖
    #            |缺省团队=过程改进团队
    #            |缺省项目=世轩维基协作平台构建项目
    #            }}
    #   }

    # MISSING example:
    #   %{
    #       ns => 0
    #       title => missing page
    #       missing =>
    #   }

    return $result;
}

sub read_page
{
    my ($page_name, $allow_missing) = @_;

    # CALL info_page()
    # REF: https://www.mediawiki.org/wiki/API:Query
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eget_page%28_$params_hashref_%29
    my $result = 0;

    $result = info_page($page_name, $allow_missing);
    if (not $result)
    {
        # page NOT found?
        return undef;
    }

    return $result->{'*'};
}

sub edit_page
{
    my ($page_name, $new_page_content, $edit_comment, $feedback, $allow_missing) = @_;

    # Allow missing by default
    $allow_missing = 1 unless defined $allow_missing;

    # CALL MediaWiki::API->edit()
    # REF: https://www.mediawiki.org/wiki/API:Changing_wiki_content
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eedit%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    # 1) Get page
    my $old_page_content = read_page($page_name, $allow_missing);
    $old_page_content = '' unless $old_page_content;

    # 2) Check difference
    if (rtrim($new_page_content) eq rtrim($old_page_content))
    {
        ${$feedback} = 'IGNORED' if $feedback;
        return 1;
    }

    # 3) Edit page
    $result = $API->edit({
            action  => 'edit',
            title   => $page_name,
            text    => $new_page_content,
            summary => $edit_comment,
            # NOTE: 存在minor键则本次编辑为小编辑, 所以即使minor=>0也是小编辑
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to edit page '$page_name', API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to edit page '$page_name', ACTION error = $result->{error}->{details}\n");
        return 0;
    }

    if ($old_page_content)
    {
        ${$feedback} = 'UPDATED' if $feedback;
    }
    else
    {
        ${$feedback} = 'CREATED' if $feedback;
    }

    # CREATE example:
    #   %{
    #       edit => %{
    #           new =>
    #           title => 2015/07/30 19:45
    #           pageid => 6272
    #           oldrevid => 0
    #           newrevid => 15882
    #           newtimestamp => 2015-07-30T11:52:12Z
    #           contentmodel => wikitext
    #           result => Success
    #       }
    #   }

    # UPDATE example:
    #   %{
    #       edit => %{
    #           title => 2015/07/30 19:53
    #           pageid => 6274
    #           oldrevid => 15884
    #           newrevid => 15885
    #           newtimestamp => 2015-07-30T12:00:52Z
    #           contentmodel => wikitext
    #           result => Success
    #       }
    #   }

    return 1;
}

sub move_page
{
    my ($old_page_name, $new_page_name, $edit_comment, $redirect) = @_;

    # CALL MediaWiki::API->edit()
    # REF: https://www.mediawiki.org/wiki/API:Move
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eedit%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    # 1) Move page
    if ($redirect)
    {
        $result = $API->edit({
                action       => 'move',
                from         => $old_page_name,
                to           => $new_page_name,
                reason       => $edit_comment,
                movetalk     => 1,
                movesubpages => 1,
            });
    }
    else
    {
        $result = $API->edit({
                action       => 'move',
                from         => $old_page_name,
                to           => $new_page_name,
                reason       => $edit_comment,
                movetalk     => 1,
                movesubpages => 1,
                noredirect   => 1,
            });
    }
    if (not $result)
    {
        warn my_encode("ERROR: failed to move page '$old_page_name' -> '$new_page_name', API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to move page '$old_page_name' -> '$new_page_name', ACTION error = $result->{error}->{details}\n");
        return 0;
    }

    # OK example 1:
    #   %{
    #       move => %{
    #           from => 周京晖
    #           to => 周京晖A
    #           reason => 单元测试
    #           subpages => @[
    #               %{
    #                   from => 周京晖/个人信息
    #                   to => 周京晖A/个人信息
    #               }
    #               ...
    #           ]
    #           subpages-talk => @[
    #           ]
    #           redirectcreated =>
    #       }
    #   }

    # OK example 2:
    #   %{
    #       move => %{
    #           from => 周京晖A
    #           to => 周京晖
    #           subpages => @[
    #               %{
    #                   from => 周京晖A/个人信息
    #                   to => 周京晖/个人信息
    #               }
    #               ...
    #           ]
    #           subpages-talk => @[
    #           ]
    #           reason => 单元测试
    #           moveoverredirect =>
    #       }
    #   }

    # OK example 3:
    #   %{
    #       move => %{
    #           from => 周京晖
    #           to => 周京晖A
    #           subpages => @[
    #               %{
    #                   to => 周京晖A/个人信息
    #                   from => 周京晖/个人信息
    #               }
    #               ...
    #           ]
    #           subpages-talk => @[
    #           ]
    #           reason => 单元测试
    #       }
    #   }

    return 1;
}

sub delete_page
{
    my ($page_name, $edit_comment, $allow_missing) = @_;

    # CALL MediaWiki::API->edit()
    # REF: https://www.mediawiki.org/wiki/API:Delete
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eedit%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    # 1) Delete page
    $result = $API->edit({
            action => 'delete',
            title  => $page_name,
            reason => $edit_comment,
        });
    if (not $result)
    {
        if ($allow_missing)
        {
            # API error = missingtitle: The page you requested doesn't exist at
        }
        else
        {
            warn my_encode("ERROR: failed to delete page '$page_name', API error = $API->{error}->{details}\n");
        }
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to delete page '$page_name', ACTION error = $result->{error}->{details}\n");
        return 0;
    }

    # OK example:
    # %{
    #     delete => %{
    #         logid => 14692
    #         title => 2015/07/31 09:20
    #         reason => 单元测试
    #     }
    # }

    return 1;
}

sub delete_page_r
{
    my ($root_page_name, $edit_comment, $allow_missing) = @_;

    # 删除主页面
    delete_page($root_page_name, $edit_comment, $allow_missing);

    # 分解空间名和页面名
    my ($ns_name, $page_name) = split /:/, $root_page_name;
    unless ($page_name)
    {
        $page_name = $ns_name;
        $ns_name = '';
    }

    # 从空间名获取空间ID
    my $ns_id = 0;
    if ($ns_name)
    {
        my $r_ns_info = query_namespaces();
        while (my ($ns_key, $r_ns_value) = each %{ $r_ns_info->{query}->{namespaces} })
        {
            my $ns_text = $r_ns_value->{'*'};
            if ($ns_text eq $ns_key)
            {
                $ns_id = $ns_key;
                last;
            }
        }
    }

    # 查询并删除子孙页面
    my $r_pages = query_pages($ns_id, $page_name . '/');
    foreach (@{ $r_pages })
    {
        my $sub_page_name = $_->{title};

        # warn my_encode("deleting page: '$sub_page_name'\n");
        delete_page($sub_page_name, $edit_comment, 0);
    }
}

# 刷新页面
sub purge_page
{
    my ($page_name) = @_;

    # CALL MediaWiki::API->api()
    # REF: https://www.mediawiki.org/wiki/API:Purge
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eapi%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    # 1) Purge page
    $result = $API->api({
            action => 'purge',
            titles => $page_name, # allow multiple pages: a|b|c|...
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to purge page '$page_name', API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to purge page '$page_name', ACTION error = $result->{error}->{details}\n");
        return 0;
    }

    # OK example:
    #    purge => @[
    #        %{
    #            ns => 0
    #            purged =>
    #            title => 丁新陶
    #        }
    #    ]
    #    batchcomplete =>

    return 1;
}

sub create_user
{
    my ($user_name, $user_mail) = @_;

    # CALL MediaWiki::API->api()
    # REF: https://www.mediawiki.org/wiki/API:Account_creation
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eapi%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    # 1) Get token
    $result = $API->api({
            action       => 'createaccount',
            name         => $user_name,
            realname     => $user_name,
            email        => $user_mail,
            mailpassword => 1,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to create user(get token) '$user_name', API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to create user(get token) '$user_name', ACTION error = $result->{error}->{details}\n");
        return 0;
    }

    # 2) Create user
    $result = $API->api({
            action       => 'createaccount',
            name         => $user_name,
            realname     => $user_name,
            email        => $user_mail,
            mailpassword => 1,
            token        => $result->{createaccount}->{token},
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to create user(create user) '$user_name', API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to create user(create user) '$user_name', ACTION error = $result->{error}->{details}\n");
        return 0;
    }

    # OK example:
    #   %{
    #       createaccount => %{
    #           token => a519e5cb8fe4b8d0c86e74b7905ae5dd
    #           result => NeedToken
    #       }
    #   }
    #   %{
    #       createaccount => %{
    #           userid => 228
    #           token => 161adac410a6e49c6de663a3db1bc666
    #           result => Success
    #           username => 测试用户2
    #       }
    #   }

    # FAILED example 1:
    #   API error = passwordtooshort: Passwords must be at least {{PLURAL:1|1 character|1 characters}}.
    # Reason: Email disabled
    # Resolution: $ vi $WIKI_HOME/LocalSettings.php -> $wgEnableEmail = true;

    # FAILED example 2:
    #   API error = php-mail-error-unknown: Unknown error in PHP's mail() function.
    # Reason: httpd mail disabled by SElinux
    # Resolution: $ setsebool -P httpd_can_sendmail 1

    # TROUBLE: password mail missing
    # Reason: password mail tagged as SPAM for unknown sender (MAYBE)
    # Resolution: $ vi $WIKI_HOME/LocalSettings.php -> $wgPasswordSender = "zhoujinghui@cnsesan.com";

    return 1;
}

sub block_user
{
    my ($wiki_user, $block_reason, $block) = @_;

    die "ERROR: 3rd parameter 'block(1) or unblock(0)' must be provided" unless defined $block;

    # CALL MediaWiki::API->api()
    # REF: https://www.mediawiki.org/wiki/API:Block
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eapi%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    # 1) Get token (MediaWiki: 1.20~1.23)
    $result = $API->api({
            action => 'tokens',
            type   => 'block',
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to block user(get token) '$wiki_user', API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to block user(get token) '$wiki_user', ACTION error = $result->{error}->{details}\n");
        return 0;
    }

    # 2) Block/Unblock user
    $result = $API->api({
            action => ($block ? 'block' : 'unblock'),
            user   => $wiki_user,
            reason => $block_reason,
            token  => $result->{tokens}->{blocktoken},
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to block user(block user) '$wiki_user', API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to block user(block user) '$wiki_user', API error = $result->{error}->{details}\n");
        return 0;
    }

    # Block example:
    #   %{
    #       tokens => %{
    #           blocktoken => 1a7450b27d88f8763630a1d29242b9e2+\
    #       }
    #   }
    #   %{
    #       block => %{
    #           id => 15
    #           user => 测试用户1
    #           userID => 227
    #           reason => 单元测试
    #           expiry => infinite
    #       }
    #   }

    # Unblock example:
    #   %{
    #       tokens => %{
    #           blocktoken => 1a7450b27d88f8763630a1d29242b9e2+\
    #       }
    #   }
    #   %{
    #       unblock => %{
    #           id => 15
    #           user => 测试用户1
    #           userid => 227
    #           reason => 单元测试
    #       }
    #   }

    return 1;
}

sub parse_page
{
    my ($page_name) = @_;

    # CALL MediaWiki::API->api()
    # REF: https://www.mediawiki.org/wiki/API:Parsing_wikitext
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eapi%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    $result = $API->api({
            action    => 'parse',
            page      => $page_name,
            disablepp => 1,
            disabletoc => 1,
            disableeditsection => 1,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to parse page '$page_name', API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to parse page '$page_name', ACTION error = $result->{error}->{details}\n");
        return undef;
    }

    # OK example:
    #   %{
    #       parse => %{
    #           images => @[
    #           ]
    #           displaytitle => 周京晖
    #           iwlinks => @[
    #           ]
    #           categories => @[
    #               %{
    #                   sortkey => 过程改进团队
    #                   * => 世轩用户的实例
    #               }
    #           ]
    #           properties => @[
    #               %{
    #                   name => smw-semanticdata-status
    #                   * => true(JSON::PP::Boolean)
    #               }
    #               %{
    #                   name => defaultsort
    #                   * => 过程改进团队
    #               }
    #           ]
    #           externallinks => @[
    #           ]
    #           revid => 15939
    #           langlinks => @[
    #           ]
    #           text => %{
    #               * => <div style="text-align:right">→ <a href="/wiki/index.php/%E5%91%A8%E4%BA%AC%E6%99%96/%E4%B8%AA%E4%BA%BA%E4%BF%A1%E6%81%AF" title="周京晖/个人信息
    #                   <table class="SMF_base_table SMF_view_table" width="100%">
    #                   ...
    #                   </table>
    #
    #                   <!--
    #                   NewPP limit report
    #                   CPU time usage: 0.439 seconds
    #                   Real time usage: 0.485 seconds
    #                   Preprocessor visited node count: 122/1000000
    #                   Preprocessor generated node count: 698/1000000
    #                   Post‐expand include size: 1708/2097152 bytes
    #                   Template argument size: 378/2097152 bytes
    #                   Highest expansion depth: 4/40
    #                   Expensive parser function count: 0/100
    #                   -->
    #
    #                   <!-- Saved in parser cache with key wiki:pcache:idhash:173-0!*!0!*!*!*!* and timestamp 20150730125434 and revision id 15939
    #                    -->
    #           }
    #           title => 周京晖
    #           sections => @[
    #           ]
    #           links => @[
    #               %{
    #                   ns => 0
    #                   * => 世轩维基协作平台构建项目
    #                   exists =>
    #               }
    #               ...
    #           ]
    #           templates => @[
    #               %{
    #                   ns => 10
    #                   * => 模板:世轩用户
    #                   exists =>
    #               }
    #               %{
    #                   ns => 0
    #                   * => 技术辅助团队/近期工作成果
    #               }
    #           ]
    #       }
    #   }

    return $result->{parse};
}

sub parse_text
{
    my ($content, $title) = @_;

    $title = 'API' unless defined $title;

    # CALL MediaWiki::API->api()
    # REF: https://www.mediawiki.org/wiki/API:Parsing_wikitext
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eapi%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    $result = $API->api({
            action    => 'parse',
            text      => $content,
            title     => $title,
            pst       => 1,
            disablepp => 1,
            disabletoc => 1,
            disableeditsection => 1,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to parse content '$content', API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to parse content '$content', ACTION error = $result->{error}->{details}\n");
        return undef;
    }

    # OK example:
    #   %{
    #       parse => %{
    #           images => @[
    #           ]
    #           displaytitle => 周京晖
    #           iwlinks => @[
    #           ]
    #           categories => @[
    #               %{
    #                   sortkey => 过程改进团队
    #                   * => 世轩用户的实例
    #               }
    #           ]
    #           properties => @[
    #               %{
    #                   name => smw-semanticdata-status
    #                   * => true(JSON::PP::Boolean)
    #               }
    #               %{
    #                   name => defaultsort
    #                   * => 过程改进团队
    #               }
    #           ]
    #           externallinks => @[
    #           ]
    #           revid => 15939
    #           langlinks => @[
    #           ]
    #           text => %{
    #               * => <div style="text-align:right">→ <a href="/wiki/index.php/%E5%91%A8%E4%BA%AC%E6%99%96/%E4%B8%AA%E4%BA%BA%E4%BF%A1%E6%81%AF" title="周京晖/个人信息
    #                   <table class="SMF_base_table SMF_view_table" width="100%">
    #                   ...
    #                   </table>
    #
    #                   <!--
    #                   NewPP limit report
    #                   CPU time usage: 0.439 seconds
    #                   Real time usage: 0.485 seconds
    #                   Preprocessor visited node count: 122/1000000
    #                   Preprocessor generated node count: 698/1000000
    #                   Post‐expand include size: 1708/2097152 bytes
    #                   Template argument size: 378/2097152 bytes
    #                   Highest expansion depth: 4/40
    #                   Expensive parser function count: 0/100
    #                   -->
    #
    #                   <!-- Saved in parser cache with key wiki:pcache:idhash:173-0!*!0!*!*!*!* and timestamp 20150730125434 and revision id 15939
    #                    -->
    #           }
    #           title => 周京晖
    #           sections => @[
    #           ]
    #           links => @[
    #               %{
    #                   ns => 0
    #                   * => 世轩维基协作平台构建项目
    #                   exists =>
    #               }
    #               ...
    #           ]
    #           templates => @[
    #               %{
    #                   ns => 10
    #                   * => 模板:世轩用户
    #                   exists =>
    #               }
    #           ]
    #       }
    #   }
    return $result->{parse};
}

sub expand_text
{
    my ($text, $title) = @_;

    $title = 'API' unless defined $title;

    # CALL MediaWiki::API->api()
    # REF: https://www.mediawiki.org/wiki/API:Parsing_wikitext
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Eapi%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    $result = $API->api({
            action => 'expandtemplates',
            title  => $title,
            text   => $text,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to parse text, API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to parse text, ACTION error = $result->{error}->{details}\n");
        return undef;
    }

    # OK example:
    # %{
    #     expandtemplates => %{
    #         * => <div style="text-align:right">→ [[周京晖/个人信息|查看个人信息]]</div> ...
    #      }
    # }

    # EMPTY example:
    # %{
    #     warnings => %{
    #         expandtemplates => %{
    #             * => Because no values have been specified for the prop parameter, a legacy format has been used for the output. This format is deprecated, and in the future, a default value will be set for the prop parameter, causing the newformat to always be used.
    #         }
    #     }
    #     expandtemplates => %{
    #         * =>
    #     }
    # }

    return repair_wiki_url($result->{expandtemplates}->{'*'});
}

sub repair_wiki_url
{
    my $wiki_text = shift;
    $wiki_text =~ s/<a href="$WIKI_PATH\//<a href="$WIKI_HOST$WIKI_PATH\//g;
    return $wiki_text;
}

sub upload_file
{
    my ($page_name, $file_name, $upload_comment, $ignore_warnings, $overwrite) = @_;

    # CALL MediaWiki::API->api()
    # REF: https://www.mediawiki.org/wiki/API:Upload
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm
    my $result = 0;

    # 1) Check file conflict
    my $file_info = info_page("File:$page_name", 1);
    if ($file_info)
    {
        warn my_encode("File already uploaded by $file_info->{user} at $file_info->{timestamp}\n"); # NOTE: hide warning location
        unless ($overwrite)
        {
            return 0;
        }
    }

    # 1) Read file content
    open UPLOAD_FILE, '<', my_encode($file_name)
        or die my_encode("Can't open upload file '$file_name' for reading, reason = $!\n");

    binmode UPLOAD_FILE; # 无此行则图片异常
    my ($input_buffer, $file_data);
    while (read(UPLOAD_FILE, $input_buffer, 65536))
    {
        $file_data .= $input_buffer;
    }

    close UPLOAD_FILE;

    # 2) Get edit token
    my $token = get_token();
    unless ($token)
    {
        # already warned in get_token()
        return 0;
    }

    # 3) Upload file
    $result = $API->api({
        action   => 'upload',
        filename => encode_utf8($page_name),
        file     => [ undef, encode_utf8($page_name), Content => $file_data ],
        comment  => encode_utf8($upload_comment),
        token    => $token,
        ignorewarnings => $ignore_warnings ? 1 : 0,
    });
    # NOTE: 必须调用api(), 调用upload()出错: 无法获取token; 参数file的数据结构参考了upload()源码
    if (not $result)
    {
        warn my_encode("ERROR: failed to upload file '$page_name', API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to upload file '$page_name', ACTION error = $result->{error}->{details}\n");
        return 0;
    }

    # OK example:
    # %{
    #     upload => %{
    #         filename => 沙漠.jpg
    #         imageinfo => %{
    #             width => 1024
    #             sha1 => 30420d1a9afb2bcb60335812569af4435a59ce17
    #             userid => 2
    #             descriptionurl => https://wiki.cnsesan.com/wiki/index.php/%E6%96%87%E4%BB%B6:%E6%B2%99%E6%BC%A0.jpg
    #             size => 845941
    #             extmetadata => %{
    #                 DateTime => %{
    #                     source => mediawiki-metadata
    #                     value => 2015-10-25T12:45:06Z
    #                     hidden =>
    #                 }
    #                 ObjectName => %{
    #                     source => mediawiki-metadata
    #                     value => 沙漠
    #                     hidden =>
    #                 }
    #             }
    #             bitdepth => 8
    #             html => 已存在相同名称的文件, 如果您无法确定您是否要改变它, 请检查<strong><strong><a href="/wiki/index.php/%E6%96%87%E4%BB%B6:%E6%B2%99%E6%BC%A0.jpg" title="文件:沙漠.jpg">文件:沙漠.jpg</a></strong></strong>。 <div class="thumb tright"><div class="thumbinner" style="width:182px;"><a href="/wiki/index.php?title=%E7%89%B9%E6%AE%8A:%E4%B8%8A%E4%BC%A0%E6%96%87%E4%BB%B6&amp;wpDestFile=%E6%B2%99%E6%BC%A0.jpg" class="new" title="文件:沙漠.jpg">文件:沙漠.jpg</a>  <div class="thumbcaption"></div></div></div>
    #
    #             timestamp => 2015-10-25T12:45:06Z
    #             url => https://wiki.cnsesan.com/wiki/images/2/2c/%E6%B2%99%E6%BC%A0.jpg
    #             user => Robot
    #             metadata => @[
    #                 %{
    #                     value => 2009:03:12 13:47:43
    #                     name => DateTime
    #                 }
    #                 %{
    #                     value => 2008:03:14 13:59:26
    #                     name => DateTimeOriginal
    #                 }
    #                 %{
    #                     value => 2008:03:14 13:59:26
    #                     name => DateTimeDigitized
    #                 }
    #                 %{
    #                     value => 54
    #                     name => SubSecTimeOriginal
    #                 }
    #                 %{
    #                     value => 54
    #                     name => SubSecTimeDigitized
    #                 }
    #                 %{
    #                     value => @[
    #                         %{
    #                             value => Corbis
    #                             name => 0
    #                         }
    #                         %{
    #                             value => ol
    #                             name => _type
    #                         }
    #                     ]
    #                     name => Artist
    #                 }
    #                 %{
    #                     value => @[
    #                         %{
    #                             value => ? Corbis.  All Rights Reserved.
    #                             name => x-default
    #                         }
    #                         %{
    #                             value => lang
    #                             name => _type
    #                         }
    #                     ]
    #                     name => Copyright
    #                 }
    #                 %{
    #                     value => 3
    #                     name => Rating
    #                 }
    #                 %{
    #                     value => 2
    #                     name => MEDIAWIKI_EXIF_VERSION
    #                 }
    #             ]
    #             canonicaltitle => 文件:沙漠.jpg
    #             height => 768
    #             mediatype => BITMAP
    #             comment => 利用UploadFiles.pl上传维基附件
    #             commonmetadata => @[
    #                 %{
    #                     value => 2009:03:12 13:47:43
    #                     name => DateTime
    #                 }
    #                 %{
    #                     value => 2008:03:14 13:59:26
    #                     name => DateTimeOriginal
    #                 }
    #                 %{
    #                     value => 2008:03:14 13:59:26
    #                     name => DateTimeDigitized
    #                 }
    #                 %{
    #                     value => 54
    #                     name => SubSecTimeOriginal
    #                 }
    #                 %{
    #                     value => 54
    #                     name => SubSecTimeDigitized
    #                 }
    #                 %{
    #                     value => @[
    #                         %{
    #                             value => Corbis
    #                             name => 0
    #                         }
    #                         %{
    #                             value => ol
    #                             name => _type
    #                         }
    #                     ]
    #                     name => Artist
    #                 }
    #                 %{
    #                     value => @[
    #                         %{
    #                             value => ? Corbis.  All Rights Reserved.
    #                             name => x-default
    #                         }
    #                         %{
    #                             value => lang
    #                             name => _type
    #                         }
    #                     ]
    #                     name => Copyright
    #                 }
    #                 %{
    #                     value => 3
    #                     name => Rating
    #                 }
    #             ]
    #             parsedcomment => 利用UploadFiles.pl上传维基附件
    #             mime => image/jpeg
    #         }
    #         result => Success
    #     }
    # }

    # Warning example:
    # upload => %{
    #     warnings => %{
    #         exists => Lighthouse.jpg
    #         badfilename => Lighthouse.jpg
    #     }
    #     filekey => 13jks6ludvps.crwq03.2.jpg
    #     sessionkey => 13jks6ludvps.crwq03.2.jpg
    #     result => Warning
    # }

    return 1;
}

sub download_file
{
    my ($page_name, $file_name) = @_;

    # CALL MediaWiki::API->download()
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm
    my $result = 0;

    # 1) 下载文件
    $result = $API->download({
        title => "File:$page_name",
    });
    if (not $result)
    {
        warn my_encode("ERROR: failed to download file '$page_name', API error = $API->{error}->{details}\n");
        return 0;
    }
    # NOTE: $result是文件字节流, 无法调用: dump_result($result);

    # 2) 保存文件
    open DOWNLOAD_FILE, '>', my_encode($file_name)
        or die my_encode("Can't save download file '$file_name', reason = $!\n");

    binmode DOWNLOAD_FILE;
    print DOWNLOAD_FILE $result;

    close DOWNLOAD_FILE;

    return 1;
}

sub get_token
{
    my $result = 0;

    $result = $API->api({
            action => 'query',
            meta   => 'tokens',
    });
    if (not $result)
    {
        warn my_encode("ERROR: failed to get token, API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to get token, ACTION error = $result->{error}->{details}\n");
        return 0;
    }
    # 2015/11/16 by zhoujh: MediaWiki-1.23不支持meta=>'tokens'类型的令牌
    if ($result->{warnings}->{query}->{'*'})
    {
        warn my_encode("ERROR: failed to get token, ACTION warning = $result->{warnings}->{query}->{'*'}\n");
        return 0;
    }

    # OK example:
    # %{
    #     query => %{
    #         tokens => %{
    #             csrftoken => 433ae8283c959320c42b6351bd8ddb6c562cc73c+\
    #         }
    #     }
    # }

    return $result->{query}->{tokens}->{csrftoken};
}

#-------------------------------------------------------------------------------

sub query_users
{
    my ($group, $prefix, $r_hook_func) = @_;

    # CALL MediaWiki::API->list()
    # REF: https://www.mediawiki.org/wiki/API:Lists + https://www.mediawiki.org/wiki/API:Allusers
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Elist%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    $result = $API->list({
            action   => 'query',
            list     => 'allusers',
            augroup  => $group,
            auprefix => $prefix,
            aulimit  => 5000,
            # blockinfo : Adds the information about a current block on the user
            # groups : Lists groups that the user is in. This uses more server resources and may return fewer results than the limit
            # implicitgroups: Lists all the groups the user is automatically in
            # rights : Lists rights that the user has
            # editcount : Adds the edit count of the user
            # registration : Adds the timestamp of when the user registered if available (may be blank) 1.12+
            auprop   => 'blockinfo|groups|implicitgroups|rights|editcount',
        },{
            max => 2,
            hook => $r_hook_func,
            # skip_encoding => 1,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to query users, API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);
    # $result->{error} NOT exists

    # OK example:
    #   @[
    #       %{
    #           rights => %{
    #               11 => move
    #               21 => reupload
    #               ...
    #           }
    #           blockexpiry => infinity
    #           userid => 106
    #           name => 丁新陶
    #           blockedby => 管理员
    #           editcount => 0
    #           blockedbyid => 1
    #           implicitgroups => @[
    #               *
    #               user
    #               autoconfirmed
    #           ]
    #           blockid => 3
    #           groups => @[
    #               *
    #               user
    #               autoconfirmed
    #           ]
    #           blockreason => 离职
    #       }
    #       %{
    #           rights => %{
    #               11 => move
    #               21 => reupload
    #               ...
    #           }
    #           editcount => 7
    #           implicitgroups => @[
    #               *
    #               user
    #               autoconfirmed
    #           ]
    #           userid => 131
    #           groups => @[
    #               *
    #               user
    #               autoconfirmed
    #           ]
    #           name => 丁莉萍
    #       }
    #       ...
    #   ]

    return $result;
}

sub query_namespaces
{
    # CALL MediaWiki::API->list()
    # REF: https://www.mediawiki.org/wiki/API:Siteinfo
    my $result = 0;

    $result = $API->api({
            action => 'query',
            meta   => 'siteinfo',
            siprop => 'namespaces',
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to query namespaces, API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);

    # OK example:
    # %{
    #     32040 => %{
    #         canonical => 工作任务
    #         * => 工作任务
    #         id => 32040
    #         case => first-letter
    #     }
    #     1 => %{
    #         canonical => Talk
    #         subpages =>
    #         * => 讨论
    #         id => 1
    #         case => first-letter
    #     }
    #     0 => %{
    #         subpages =>
    #         content =>
    #         * =>
    #         id => 0
    #         case => first-letter
    #     }
    #     -1 => %{
    #         canonical => Special
    #         * => 特殊
    #         id => -1
    #         case => first-letter
    #     }
    #     -2 => %{
    #         canonical => Media
    #         * => 媒体文件
    #         id => -2
    #         case => first-letter
    #     }
    #     ...
    # }
    return $result->{query}->{namespaces};
}

sub query_categories
{
    my ($prefix, $r_hook_func) = @_;

    # CALL MediaWiki::API->list()
    # REF: https://www.mediawiki.org/wiki/API:Lists + https://www.mediawiki.org/wiki/API:Allcategories
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Elist%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    $result = $API->list({
            action   => 'query',
            list     => 'allcategories',
            acprefix => $prefix,
            acprop   => 'size|hidden',
            aclimit  => 5000,
        },{
            max => 20,
            hook => $r_hook_func,
            # skip_encoding => 1,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to query categories, API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);
    # $result->{error} NOT exists

    # OK example:
    #   @[
    #       %{
    #           * => 项目评审的表单
    #           size => 2
    #           subcats => 2
    #           files => 0
    #           pages => 0
    #       }
    #       ...
    #   ]

    return $result;
}

sub query_pages
{
    my ($ns_id, $prefix, $type, $r_hook_func) = @_;

    $type = 'all' unless defined $type; # type = { all | redirects | nonredirects }

    # CALL MediaWiki::API->list()
    # REF: https://www.mediawiki.org/wiki/API:Lists + https://www.mediawiki.org/wiki/API:Allpages
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Elist%28_$query_hashref,_$options_hashref_%29
    # hook function:
    # sub print_articles {
    #     my ($ref) = @_;
    #     foreach (@$ref) {
    #         print "$_->{title}\n";
    #     }
    # }

    my $result = 0;

    $result = $API->list({
            action        => 'query',
            list          => 'allpages',
            apnamespace   => $ns_id,
            apprefix      => $prefix,
            # all: List all pages regardless of their redirect flag
            # redirects: Only list redirects
            # nonredirects: Don't list redirects
            apfilterredir => $type,
            aplimit       => 5000,
        },{
            max => 200,
            hook => $r_hook_func,
            # skip_encoding => 1,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to query pages, API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);
    # $result->{error} NOT exists

    # OK example:
    #   @[
    #       %{
    #           ns => 6
    #           pageid => 1085
    #           title => 文件:水母.jpg
    #       }
    #       ...
    #   ]

    return $result;
}

sub query_backlinks
{
    my ($page_name, $r_hook_func) = @_;

    # CALL MediaWiki::API->list()
    # REF: https://www.mediawiki.org/wiki/API:Lists + https://www.mediawiki.org/wiki/API:Backlinks
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Elist%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    $result = $API->list({
            action  => 'query',
            list    => 'backlinks',
            bltitle => $page_name,
            bllimit => 5000,
            blredirect => 1,
        },{
            max => 200,
            hook => $r_hook_func,
            # skip_encoding => 1,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to query pages, API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);
    # $result->{error} NOT exists

    # @[
    #     %{
    #         ns => 32042
    #         pageid => 14727
    #         title => 工作报告:周京晖/个人周报/2015-10-18
    #     }
    #     %{
    #         ns => 32042
    #         pageid => 14761
    #         title => 工作报告:周京晖/个人日报/2015-10-19
    #     }
    #     %{
    #         ns => 32042
    #         pageid => 14923
    #         title => 工作报告:周京晖/个人日报/2015-10-20
    #     }
    #     %{
    #         ns => 10
    #         pageid => 14963
    #         title => 模板:团队的考勤面板
    #     }
    #     %{
    #         ns => 10
    #         pageid => 14964
    #         title => 模板:团队的任务面板
    #     }
    #     %{
    #         ns => 0
    #         pageid => 15054
    #         title => 【催办事项】000001
    #     }
    # ]

    return $result;
}

sub query_category_members
{
    my ($category, $ns_id, $type, $r_hook_func) = @_;

    $type = 'page|subcat|file' unless defined $type;

    # CALL MediaWiki::API->list()
    # REF: https://www.mediawiki.org/wiki/API:Lists + https://www.mediawiki.org/wiki/API:Categorymembers
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Elist%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    $result = $API->list({
            action        => 'query',
            list          => 'categorymembers',
            cmtitle       => "Category:$category",
            cmnamespace   => $ns_id,
            # page, subcat, file
            cmtype        => $type,
            # ids: Page ID
            # title: Page title
            # sortkey: The sortkey used for sorting in the category (hexadecimal string)
            # sortkeyprefix: The sortkey prefix used for sorting in the category (human-readable part of the sortkey) 1.17+
            # type: Type that the page has been categorised as (page, subcat or file) 1.17+
            # timestamp: Time and date the article was added to the category
            cmprop        => 'ids|title|type',
            cmlimit       => 5000,
        },{
            max => 20,
            hook => $r_hook_func,
            # skip_encoding => 1,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to query category members, API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);
    # $result->{error} NOT exists

    # OK example:
    #   @[
    #       %{
    #           ns => 14
    #           pageid => 466
    #           type => subcat
    #           title => 分类:世轩产品的实例
    #       }
    #       ...
    #   ]

    return $result;
}

sub query_category_members_r
{
    my ($category, $ns_id, $type, $r_members, $depth) = @_;

    $type = 'page|subcat|file' unless defined $type;
    $depth = 0 unless defined $depth;

    # CALL MediaWiki::API->list()
    # REF: https://www.mediawiki.org/wiki/API:Lists + https://www.mediawiki.org/wiki/API:Categorymembers
    # REF: https://search.cpan.org/~exobuzz/MediaWiki-API-0.40/lib/MediaWiki/API.pm#MediaWiki::API-%3Elist%28_$query_hashref,_$options_hashref_%29
    my $result = 0;

    $result = $API->list({
            action        => 'query',
            list          => 'categorymembers',
            cmtitle       => "Category:$category",
            cmnamespace   => $ns_id,
            # page, subcat, file
            cmtype        => 'page|subcat|file',
            # ids: Page ID
            # title: Page title
            # sortkey: The sortkey used for sorting in the category (hexadecimal string)
            # sortkeyprefix: The sortkey prefix used for sorting in the category (human-readable part of the sortkey) 1.17+
            # type: Type that the page has been categorised as (page, subcat or file) 1.17+
            # timestamp: Time and date the article was added to the category
            cmprop        => 'ids|title|type',
            cmlimit       => 5000,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to query category members, API error = $API->{error}->{details}\n");
        return 0;
    }
    # dump_result($result);
    # $result->{error} NOT exists

    # OK example:
    #   @[
    #       %{
    #           ns => 14
    #           pageid => 466
    #           type => subcat
    #           title => 分类:世轩产品的实例
    #       }
    #       ...
    #   ]

    # 处理查询结果, 存入返回结果集
    my @expect_types = split /\|/, $type;

    foreach (@{ $result })
    {
        my $member_type = $_->{type};
        my $member_name = $_->{title};

        # println('    ' x $depth . "+ $member_name ($member_type)");

        if (grep { $_ eq $member_type } @expect_types)
        {
            $r_members->{$member_type}->{$member_name} .= $category . ', ';
        }

        if ($member_type eq 'subcat')
        {
            my $sub_category = substr $member_name, 3; # 删除开头的"分类:"

            query_category_members_r($sub_category, $ns_id, $type, $r_members, $depth + 1)
                or warn my_encode("ERROR: failed to query sub category members for '$member_name'\n");
        }
    }

    return 1;
}

sub query_site_info
{
    my $site_prop = shift;

    # 缺省查询'general'属性类
    $site_prop = 'general' unless defined $site_prop;

    # CALL MediaWiki::API->list()
    # REF: https://www.mediawiki.org/wiki/API:Siteinfo
    my $result = 0;

    $result = $API->api({
            action => 'query',
            meta   => 'siteinfo',
            siprop => $site_prop,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to query site info, API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);

    # OK example:
    #   %{
    #       query => %{
    #           general => %{
    #               generator => MediaWiki 1.23.8
    #               server => https://zhoujinghui.cn
    #               linktrail => /^()(.*)$/sD
    #               base => https://zhoujinghui.cn/wiki/index.php/%E7%94%A8%E6%88%B7:Robot/%E4%B8%BB%E9%A1%B5
    #               timezone => Asia/Shanghai
    #               lang => zh-cn
    #               scriptpath => /wiki
    #               phpversion => 5.3.3
    #               linkprefixcharset =>
    #               imagelimits => @[
    #                   %{
    #                       width => 320
    #                       height => 240
    #                   }
    #                   %{
    #                       width => 640
    #                       height => 480
    #                   }
    #                   %{
    #                       width => 800
    #                       height => 600
    #                   }
    #                   %{
    #                       width => 1024
    #                       height => 768
    #                   }
    #                   %{
    #                       width => 1280
    #                       height => 1024
    #                   }
    #               ]
    #               fallback => @[
    #                   %{
    #                       code => zh-hans
    #                   }
    #                   %{
    #                       code => en
    #                   }
    #               ]
    #               sitename => 世轩科技维基百科
    #               langconversion =>
    #               timeoffset => 480
    #               mainpage => 用户:Robot/主页
    #               imagewhitelistenabled =>
    #               time => 2015-10-21T07:47:27Z
    #               fallback8bitEncoding => windows-936
    #               dbversion => 5.1.71
    #               case => first-letter
    #               linkprefix =>
    #               variantarticlepath => false(JSON::PP::Boolean)
    #               writeapi =>
    #               dbtype => mysql
    #               thumblimits => @[
    #                   120
    #                   150
    #                   180
    #                   200
    #                   250
    #                   300
    #               ]
    #               articlepath => /wiki/index.php/$1
    #               wikiid => wiki
    #               script => /wiki/index.php
    #               titleconversion =>
    #               phpsapi => apache2handler
    #               favicon => https://zhoujinghui.cn/favicon.ico
    #               maxuploadsize => 104857600
    #               logo => https://zhoujinghui.cn/wiki/skins/common/images/logo.png
    #           }
    #       }
    #   }

    return $result->{query}->{$site_prop};
}

sub query_base_url
{
    return $WIKI_URL;
}

sub query_user_touch
{
    my $user = shift;

    # CALL MediaWiki::API->api()
    my $result = 0;

    $result = $API->api({
            action => 'user_touch_time',
            user   => $user,
        });
    if (not $result)
    {
        warn my_encode("ERROR: failed to get user touch time, API error = $API->{error}->{details}\n");
        return undef;
    }
    # dump_result($result);
    if ($result->{error}->{code})
    {
        warn my_encode("ERROR: failed to get user touch time, ACTION error = $result->{error}->{details}\n");
        return undef;
    }

    # OK example:
    # %{
    #     result => %{
    #         user_name => 丁莉萍
    #         user_touched => 20150728091807
    #     }
    # }

    return $result->{result}->{user_touched};
}

#-------------------------------------------------------------------------------
# 世轩维基常用查询
#-------------------------------------------------------------------------------

sub query_wiki_objects
{
    my $object_name = shift;
    my $result = query_category_members("${object_name}的实例", undef, 'page');
    # dump_result($result);
    return $result;
}

#-------------------------------------------------------------------------------
1;
