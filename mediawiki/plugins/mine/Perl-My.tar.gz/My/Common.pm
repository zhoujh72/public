
#-------------------------------------------------------------------------------
# Package Name
#-------------------------------------------------------------------------------

package My::Common;

#-------------------------------------------------------------------------------
# Compile Options
#-------------------------------------------------------------------------------

use strict;
use warnings;

#-------------------------------------------------------------------------------
# Import Modules
#-------------------------------------------------------------------------------

use utf8; # 当前脚本是UTF8编码(utf8 flag = ON)

use Encode;
use Encode::CN; # 手工包含本模块: 解决pp打包时出现的"The locale codeset (cp936) isn't one that perl can decode ..."和"Unknown encoding 'GBK' ..."问题
use File::Basename;
use Time::HiRes qw(gettimeofday tv_interval);
use Net::SMTP_auth;
use MIME::Lite;
use Algorithm::Diff;
use Spreadsheet::ParseExcel;
use Spreadsheet::ParseExcel::FmtUnicode;
use Spreadsheet::WriteExcel;
use LWP::Simple;
use JSON;
use Date::Calc;

#-------------------------------------------------------------------------------
# Export Interface
#-------------------------------------------------------------------------------

require Exporter;

our (@ISA, @EXPORT, @EXPORT_OK);

# CLASS list
@ISA = qw(
    Exporter
);

# FUNCTION list
@EXPORT = qw(
    nvl
    max
    min
    sum
    avg
    round
    roundex

    css_pt2px
    css_px2pt
    css_ch2px
    css_ch2pt

    ltrim
    rtrim
    trim
    regulate
    lpad
    rpad
    indent

    number_in_array
    string_in_array

    prints
    println
    open_input_file
    open_output_file
    load_file
    save_file
    load_excel_file
    save_excel_file

    my_encode
    my_decode
    init_env
    check_args
    run_cmd
    quit

    diff
    sdiff
    send_mail
    send_batch_mails

    today
    now
    add_date
    add_time

    next_test
    test_number
    test_string

    http_head
    http_get
    json_encode
    json_decode

    dump_variable
);

# NOTE: @EXPORT_OK和@EXPORT的区别请参考: http://stackoverflow.com/questions/17912400/export-vs-export-ok-in-perl
@EXPORT_OK = qw(
);

#-------------------------------------------------------------------------------
# Internal Constants
#-------------------------------------------------------------------------------

my $SMTP_SERVER = 'smtp.cnsesan.com';

#-------------------------------------------------------------------------------
# Internal Variables
#-------------------------------------------------------------------------------

# 终端编码
my $ENV_ENCODING = "utf8";

# 缩进级数
my $DUMP_LEVEL = 0;

# 脚本启动时间
my @PROG_BEGIN_TIME;

# 脚本结束时间
my @PROG_END_TIME;

#-------------------------------------------------------------------------------
# Export Variables (@EXPORT_OK)
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# Export Functions (@EXPORT)
#-------------------------------------------------------------------------------

sub nvl
{
    my ($value, $default) = @_;
    return defined($value) ? $value : $default
}

sub max
{
    my $max = shift;
    map { $max = $_ if $_ > $max; } @_;
    return $max;
}

sub min
{
    my $min = shift;
    map { $min = $_ if $_ < $min; } @_;
    return $min;
}

sub sum
{
    my $sum = 0;
    map { $sum += $_ } @_;
    return $sum;
}

sub avg
{
    my $sum = 0;
    map { $sum += $_ } @_;
    return $sum / @_;
}

# 浮点数取整
sub round
{
    my $float = shift;
    return int($float + ($float >=0 ? 0.5 : -0.5));
}

# 浮点数保留N位小数
sub roundex
{
    my ($float, $length) = @_;
    my $base = 10 ** $length;
    my $extra = $float >= 0 ? 0.5 : -0.5;
    return int($float * $base + $extra) / $base;
}

#-------------------------------------------------------------------------------

# CSS单位转换: point -> pixel
sub css_pt2px
{
    my $points = shift;
    return round($points * 1.333);
}

# CSS单位转换: pixel -> pt
sub css_px2pt
{
    my $points = shift;
    return round($points / 1.333);
}

# CSS单位转换: char -> pixel
sub css_ch2px
{
    my $chars = shift;
    return round($chars * 8);
}

# CSS单位转换: char -> point
sub css_ch2pt
{
    my $chars = shift;
    return round($chars * 8 / 1.333);
}

#-------------------------------------------------------------------------------

# 删除串首空白字符
sub ltrim
{
    my ($string, $max_count) = @_;

    return undef unless defined $string;

    if (defined $max_count)
    {
        $string =~ s/^\s{0,$max_count}//; # NOTE: $max_count maybe 0
    }
    else
    {
        $string =~ s/^\s+//;
    }

    return $string;
}

# 删除串尾空白字符
sub rtrim
{
    my ($string, $max_count) = @_;

    return undef unless defined $string;

    if (defined $max_count)
    {
        $string =~ s/\s{0,$max_count}$//; # NOTE: $max_count maybe 0
    }
    else
    {
        $string =~ s/\s+$//;
    }

    return $string;
}

# 删除串首尾空白字符
sub trim
{
    my $string = shift;

    return undef unless defined $string;

    $string =~ s/^\s+//;
    $string =~ s/\s+$//;

    return $string;
}

# 删除串首尾空白字符, 合并串中连续空白字符
sub regulate
{
    my $string = shift;

    return undef unless defined $string;

    $string =~ s/^\s*(.*?)\s*$/$1/s; # NOTE: 非/s模式下, .不匹配回车
    $string =~ s/\s+/ /g;

    return $string;
}

# 在字符串的左边填充空格至指定宽度
sub lpad
{
    my ($string, $width) = @_;

    my $spaces = $width - length(my_encode($string));
    if ($spaces > 0)
    {
        $string .= (' ' x $spaces);
    }

    return $string;
}

# 在字符串的右边填充空格至指定宽度
sub rpad
{
    my ($string, $width) = @_;

    my $spaces = $width - length(my_encode($string));
    if ($spaces > 0)
    {
        $string = (' ' x $spaces) . $string;
    }

    return $string;
}

# 在非首行字符串的左边填充指定空格数量(用于缩进)
sub indent
{
    my ($string, $width) = @_;

    my @lines = split "\n", $string;

    return join "\n" . ' ' x $width, @lines;
}

#-------------------------------------------------------------------------------

sub number_in_array
{
    my ($element, @array) = @_;

    return (grep { $_ == $element } @array) ? 1 : 0;
}

sub string_in_array
{
    my ($element, @array) = @_;

    return (grep { $_ eq $element } @array) ? 1 : 0;
}

#-------------------------------------------------------------------------------

sub prints
{
    foreach (@_)
    {
        print my_encode($_);
    }
}

sub println
{
    foreach (@_)
    {
        print my_encode($_);
    }
    print "\n";
}

sub open_input_file
{
    my ($file_name, $mode) = @_;
    $mode = '< :encoding(utf8)' unless defined $mode;
    open INPUT_FILE, $mode, my_encode($file_name)
        or die my_encode("Can't open input file '$file_name' for reading, reason = $!\n");
    return \*INPUT_FILE;
}

sub open_output_file
{
    my ($file_name, $mode) = @_;
    $mode = '> :encoding(utf8)' unless defined $mode;
    open OUTPUT_FILE, $mode, my_encode($file_name)
        or die my_encode("Can't open output file '$file_name' for writing, reason = $!\n");
    binmode OUTPUT_FILE, 'raw:utf8';
    return \*OUTPUT_FILE;
}

sub load_file
{
    my ($file_name, $mode) = shift;
    $mode = '< :encoding(utf8)' unless defined $mode;
    open INPUT_FILE, $mode, my_encode($file_name)
        or die my_encode("Can't load file '$file_name', reason = $!\n");
    my @file_content = <INPUT_FILE>;
    close INPUT_FILE;
    return join('', @file_content);
}

sub save_file
{
    my ($file_name, $file_content, $mode) = @_;
    $mode = '> :encoding(utf8)' unless defined $mode;
    open OUTPUT_FILE, $mode, my_encode($file_name)
        or die my_encode("Can't save file '$file_name', reason = $!\n");
    binmode OUTPUT_FILE, 'raw:utf8';
    print OUTPUT_FILE $file_content;
    close OUTPUT_FILE;
}

sub load_excel_file
{
    my ($excel_file, $indent) = @_;

    my $result = [];

    my $parser = new Spreadsheet::ParseExcel;
    my $formatter = new Spreadsheet::ParseExcel::FmtUnicode(Unicode_Map => 'CP936'); # CP936 & GB2312(遗漏特殊字符) => YES, GBK => NO
    my $excel_book = $parser->parse(my_encode($excel_file), $formatter)
        or die my_encode("ERROR: can't open input excel file '$excel_file'");

    my $sheet_index = 0;
    foreach my $excel_sheet($excel_book->worksheets())
    {
        my $sheet_name = my_decode($excel_sheet->get_name());

        println($indent . "+ Reading sheet '$sheet_name' ...");

        $result->[$sheet_index] = { sheet_name => $sheet_name, sheet_headers => [], sheet_records => [] };

        # sheet: data range
        my ($min_row, $max_row) = $excel_sheet->row_range();
        my ($min_col, $max_col) = $excel_sheet->col_range();

        # 空表: row_range => (0, -1), col_range => (0, -1)
        next if $min_row > $max_row or $min_col > $max_col;

        # 读取列名
        foreach my $col_index(0 .. $max_col)
        {
            my $header_name = get_cell_value($excel_sheet->get_cell(0, $col_index));
            $result->[$sheet_index]->{sheet_headers}->[$col_index] = $header_name;
        }

        # 读取记录
        foreach my $row_index(1 .. $max_row)
        {
            foreach my $col_index(0 .. $max_col)
            {
                my $cell_value = get_cell_value($excel_sheet->get_cell($row_index , $col_index));
                $result->[$sheet_index]->{sheet_records}->[$row_index]->[$col_index] = $cell_value;
            }
        }

        $sheet_index ++;
    }

    $excel_book->close();

    return $result;
}

sub save_excel_file
{
    my ($excel_file, $r_data, $indent) = @_;

    # 创建EXCEL文件
    my $excel_book = new Spreadsheet::WriteExcel(my_encode($excel_file))
        or warn my_encode("ERROR: can't open output excel file '$excel_file'");

    return 0 unless $excel_book;

    # ...
    my $header_format;
    my @cell_formats;

    foreach (@{ $r_data })
    {
        my $sheet_name      = $_->{sheet_name};
        my $r_sheet_headers = $_->{sheet_headers};
        my $r_sheet_records = $_->{sheet_records};
        my $r_col_colors    = $_->{col_colors};
        my $r_col_bgcolors  = $_->{col_bgcolors};
        my $r_col_widths    = $_->{col_widths};

        # 创建EXCEL表单
        my $excel_sheet = $excel_book->add_worksheet($sheet_name)
            or warn my_encode("ERROR: can't create worksheet '$sheet_name'");

        next unless $excel_sheet;

        # 写入EXCEL表单
        my $col_index = 0;
        foreach my $header_name(@{ $r_sheet_headers })
        {
            # 写第N个列头
            unless ($header_format)
            {
                $header_format = $excel_book->add_format();
                $header_format->set_font('微软雅黑');
                $header_format->set_size(9);
                $header_format->set_border(1);
                $header_format->set_color('white');
                $header_format->set_bg_color('green');
            }

            $excel_sheet->write_string(0, $col_index, $header_name, $header_format);
            $excel_sheet->set_column($col_index, $col_index, $r_col_widths->[$col_index]) if $r_col_widths and $r_col_widths->[$col_index];

            # 写第N列数据
            my $cell_format = $cell_formats[$col_index];
            unless ($cell_format)
            {
                $cell_format = $excel_book->add_format();
                $cell_format->set_font('微软雅黑');
                $cell_format->set_size(9);
                $cell_format->set_border(1);
                $cell_format->set_color($r_col_colors->[$col_index]) if $r_col_colors and $r_col_colors->[$col_index];
                $cell_format->set_bg_color($r_col_bgcolors->[$col_index]) if $r_col_bgcolors and $r_col_bgcolors->[$col_index];
                $cell_formats[$col_index] = $cell_format;
            }

            my $row_index = 0;
            foreach my $record(@{ $r_sheet_records })
            {
                $excel_sheet->write_string($row_index, $col_index, $record->[$col_index], $cell_format);
                $row_index ++;
            }

            $col_index ++;
        }
    }

    $excel_book->close();

    return 1;
}

sub get_cell_value
{
    my $cell = shift;
    my $cell_value = $cell ? my_decode($cell->value()) : '';
    return $cell_value;
}

#-------------------------------------------------------------------------------

sub init_env
{
    @PROG_BEGIN_TIME = gettimeofday() unless @PROG_BEGIN_TIME;

    my $encoding = shift;
    unless ($encoding)
    {
        if ($^O eq 'MSWin32')
        {
            $encoding = 'GBK';
        }
    }
    $| = 1;
    $ENV_ENCODING = $encoding if $encoding;
    # println("ENV_ENCODING = $ENV_ENCODING");

    push @INC, $ENV{PERL5LIB} if $ENV{PERL5LIB};
}

sub my_encode
{
    return encode($ENV_ENCODING, shift);
}

sub my_decode
{
    return decode($ENV_ENCODING, shift);
}

sub check_args
{
    my ($min_args, $max_args, @expect_args) = @_;

    my $actual_args = @ARGV;
    if ($actual_args < $min_args or $actual_args > $max_args)
    {
        my $prog = basename($0);

        if ($#ARGV <= 0)
        {
             println("请提供参数（注意：如果确实提供了参数，请尝试以\"perl 脚本名.pl 参数列表\"的方式来运行）");
        }
        else
        {
            println("实际参数:");
            foreach (0 .. $#ARGV)
            {
                println("    $_ = " . my_decode($ARGV[$_]));
            }
        }

        die my_encode("用法: $prog @expect_args\n");
    }
}

sub run_cmd
{
    my $parse_command = shift;
    # println("    \$ $parse_command");
    system(my_encode($parse_command))
        and die my_encode("ERROR: Failed to execute command:\n    command = $parse_command\n    reason = $? ($!)\n");
}

sub quit
{
    my $info = shift;

    if (not $info)
    {
        @PROG_END_TIME = gettimeofday();
        $info = "*** 脚本执行成功(" . tv_interval(\@PROG_BEGIN_TIME, \@PROG_END_TIME) * 1000 . " ms) ***";
    }

    println("\n$info\n"); # 前后加空行

    exit;
}

#-------------------------------------------------------------------------------

sub diff
{
    my ($old_text, $new_text, $prefix) = @_;

    $prefix = '' unless $prefix;

    # find changes
    my @old_lines = split /\n/, $old_text;
    my @new_lines = split /\n/, $new_text;

    my @diff_lines = Algorithm::Diff::diff(\@old_lines, \@new_lines);

    # sort by line number
    my %changes;

    foreach my $diff_block(@diff_lines)
    {
        foreach my $diff_line(@{ $diff_block })
        {
            my ($tag, $line, $change) = @{ $diff_line };

            if ($tag eq '-')
            {
                $changes{$line}->{OLD} = $change;
            }
            else
            {
                $changes{$line}->{NEW} = $change;
            }
        }
    }

    # generate decription
    my $result;

    foreach my $line(sort keys %changes)
    {
        my $old = $changes{$line}->{OLD};
        my $new = $changes{$line}->{NEW};

        $old = '(空)' unless $old;
        $new = '(空)' unless $new;

        $result .= $prefix . sprintf("第%03d行: $old  ->  $new\n", $line);
    }

    return $result;
}

sub sdiff
{
    my ($old_text, $new_text, $prefix) = @_;

    $prefix = '' unless $prefix;

    # find changes
    my @old_lines = split /\n/, $old_text;
    my @new_lines = split /\n/, $new_text;

    my @changes = Algorithm::Diff::sdiff(\@old_lines, \@new_lines);

    # generate decription
    my $result;

    foreach (@changes)
    {
        my ($tag, $old, $new) = @{ $_ };

        if ($tag eq '-')
        {
            $result .= $prefix . "$old  ->  (删除)\n";
            next;
        }

        if ($tag eq '+')
        {
            $result .= $prefix . "(增加)  ->  $new\n";
            next;
        }

        if ($tag eq 'c')
        {
            $result .= $prefix . "$old  ->  $new\n";
            next;
        }

        println("UNKNONW: '$tag'") if $tag ne 'u';
    }

    return $result;
}

sub send_mail
{
    my ($send_user, $send_pass, $r_one_mail, $send_flag) = @_;
    send_batch_mails($send_user, $send_pass, [ $r_one_mail ], $send_flag, 0, 1);
}

sub send_batch_mails
{
    my ($send_user, $send_pass, $r_mail_list, $send_flag, $begin_index, $batch_count) = @_;

    return if $batch_count <= 0;

    # default values
    $send_flag   = 0       unless defined $send_flag;
    $begin_index = 0       unless defined $begin_index;
    $batch_count = 1000000 unless defined $batch_count;

    # help variable
    my $end_index = $begin_index + $batch_count - 1;

    # connect mail sever
    my $smtp = new Net::SMTP_auth($SMTP_SERVER)
        or die my_encode("ERROR: failed to create SMTP object, reason = '$!'\n");

    # login mail server
    $smtp->auth('LOGIN', $send_user, $send_pass)
        or die my_encode("ERROR: failed to identify sender '$send_user', reason = '$!'\n");

    foreach ($begin_index .. $end_index)
    {
        my $mail_record = $r_mail_list->[$_];

        last unless defined $mail_record;

        my $mail_from        = $mail_record->{FROM};
        my $mail_to          = $mail_record->{TO};
        my $mail_cc          = $mail_record->{CC};
        my $mail_subject     = $mail_record->{SUBJECT};
        my $mail_content     = $mail_record->{CONTENT};
        my $mail_attachments = $mail_record->{ATTACHMENTS};
        my $mail_type        = $mail_record->{TYPE} ? $mail_record->{TYPE} : 'text/plain';

        my %mail_data = (
            From    => $mail_from,
            To      => $mail_to,
            Subject => $mail_subject,
            Type    => $mail_type,
            Data    => $mail_content
        );
        $mail_data{Cc} = $mail_cc if $mail_cc;

        # create mail body
        my $mime = new MIME::Lite(%mail_data)
            or die my_encode("ERROR: failed to create MIME object, reason = '$!'\n");

        # 设置字符编码
        $mime->attr('content-type.charset' => 'utf8');

        # add mail attachments
        if ($mail_attachments)
        {
            # 附件名称用|分隔
            foreach(split /\|/, $mail_attachments)
            {
                $mime->attach(Type     => 'auto',
                              Path     => $_,
                              Filename => basename($_));
            }
        }

        # get mail MIME string
        my $mime_string = $mime->as_string()
            or die my_encode("ERROR: failed to get MIME string, reason = '$!'\n");

        # send out mail
        $smtp->reset();

        prints("    Sending email '$mail_subject' to '$mail_to' ... ");

        unless ($smtp->mail($mail_from))
        {
            warn my_encode("ERROR: failed to send mail for sender '$mail_from': " . $smtp->message(). "\n");
            next;
        }
        unless ($smtp->to($mail_to))
        {
            warn my_encode("ERROR: failed to send mail for receiver '$mail_to': " . $smtp->message(). "\n");
            next;
        }
        unless (not $mail_cc or $smtp->cc($mail_cc))
        {
            warn my_encode("ERROR: failed to send mail for CCer '$mail_cc': " . $smtp->message(). "\n");
            next;
        }

        if ($send_flag)
        {
            $smtp->data()
                or die my_encode("ERROR: failed to call Net::SMTP::data(): " . $smtp->message(). "\n");
            $smtp->datasend($mime_string)
                or die my_encode("ERROR: failed to call Net::SMTP::datasend(): " . $smtp->message(). "\n");
            $smtp->dataend()
                or die my_encode("ERROR: failed to call Net::SMTP::dataend(): " . $smtp->message(). "\n");

            println('OK');
        }
        else
        {
            println('TESTED');
        }

        $smtp->reset();
    }

    # logout mail server
    $smtp->quit();
}

#-------------------------------------------------------------------------------

sub today
{
    my ($year, $month, $day) = Date::Calc::Today();
    return sprintf("%04d/%02d/%02d", $year, $month, $day);
}

sub now
{
    my ($hour, $min, $sec) =  Date::Calc::Now();
    return sprintf("%02d:%02d:%02d", $hour, $min, $sec);
}

sub add_date
{
    my ($date, $years, $months, $days) = @_;
    my $sep = substr($date, 4, 1);
    my ($year, $month, $day) = Date::Calc::Add_Delta_YMD(split(/$sep/, $date), $years, $months, $days);
    return sprintf("%04d$sep%02d$sep%02d", $year, $month, $day);
}

sub add_time
{
    my ($time, $hours, $mins, $secs) = @_;
    my ($year, $month, $day, $hour, $min, $sec) = Date::Calc::Add_Delta_DHMS(1900,1,1, split(/:/, $time), 0, $hours, $mins, $secs);
    return sprintf("%02d:%02d:%02d", $hour, $min, $sec);
}

#-------------------------------------------------------------------------------

sub next_test
{
    my $r_case_no = shift;
    my $case_no = ++ ${$r_case_no};
    println("--------- TEST #$case_no ---------");
}

sub test_number
{
    my ($test_func, $test_case, $test_value, $expect_value) = @_;
    println("FAILED: $test_func() # $test_case, return = $test_value, expect = $expect_value") if $test_value != $expect_value;
}

sub test_string
{
    my ($test_func, $test_case, $test_value, $expect_value) = @_;
    println("FAILED: $test_func() # $test_case, return = $test_value, expect = $expect_value") if $test_value ne $expect_value;
}

#-------------------------------------------------------------------------------

sub http_head
{
    my $url = shift;
    my ($content_type, $document_length, $modified_time, $expires, $server) = head($url);
    return {
        CONTENT_TYPE    => $content_type,
        DOCUMENT_LENGTH => $document_length,
        MODIFIED_TIME   => $modified_time,
        EXPIRES         => $expires,
        SERVER          => $server
    };
}

sub http_get
{
    my $url = shift;
    return get($url);
}

sub json_encode
{
    my ($perl_object, $pretty) = @_;
    return JSON->new->utf8(0)->pretty($pretty ? 1 : 0)->encode($perl_object); # 缺省是UTF8，不需要再转换
}

sub json_decode
{
    my ($json_string) = @_;
    return JSON->new->utf8(0)->decode($json_string); # 缺省是UTF8，不需要再转换
}

sub dump_variable
{
    my $dump_var = shift;

    my $dump_text = "";

    my $ref_type = ref($dump_var);
    my $indent = "    " x $DUMP_LEVEL;

    $DUMP_LEVEL ++;

    if ($ref_type eq "")
    {
        $dump_text .= "$dump_var";
    }
    elsif ($ref_type eq 'ARRAY')
    {
        $dump_text .= "\@[\n";
        foreach (@$dump_var)
        {
            $dump_text .= $indent . "    " . dump_variable($_) . "\n";
        }
        $dump_text .= $indent . "]";
    }
    elsif ($ref_type eq 'HASH')
    {
        $dump_text .= "\%{\n";
        while (my ($key, $value) = each %$dump_var)
        {
            $dump_text .= $indent . "    " . "$key => " . dump_variable($value) . "\n";
        }
        $dump_text .= $indent . "}";
    }
    else
    {
        $dump_text .= "$dump_var($ref_type)";
    }

    $DUMP_LEVEL --;

    return $dump_text;
}

#-------------------------------------------------------------------------------
1;
