<?php

# API帮助:
# http://your-wiki-url/api.php
# http://your-wiki-url/api.php?action=paraminfo&modules=user_touch_time

# 可选基类:
# + ApiBase: for a top-level module
# + ApiQueryBase: for a non-generator submodule of action=query
# + ApiQueryGeneratorBase: for a submodule of action=query with generator functionality

class ApiUserTouchTime extends ApiBase
{
    # 编辑操作请提供下列函数:
    # + needsToken(): return true
    # + getTokenSalt(): to return the token salt (or an empty string if there is none)

    # 业务函数:
    # + execute()
    # + executeGenerator() # if GeneratorModule
    public function execute()
    {
        # ApiBase::getPossibleErrors()

        # Get specific parameters
        # Using ApiMain::getVal makes a record of the fact that we've
        # used all the allowed parameters. Not doing this would add a
        # warning () to the returned data.
        # If the warning doesn't bother you, you can use
        # $params = $this->extractRequestParams();
        # to get all parameters as an associative array (e. g. $params[ 'param1' ])
        #
        # 获取API参数
        # 1)调用 ApiMain::getVal() 可消除警告: "Unrecognized parameter"
        #   $param1 = $this->getMain()->getVal('param1');
        # 2)调用 $this->extractRequestParams() 生成字典但无法消除警告
        #   $params = $this->extractRequestParams();

        # 获取用户名
        $user = $this->getMain()->getVal('user');

        # 查询上次活动时间
        $user_touch_time = $this->getDB()->selectField('user', 'user_touched', array('user_name' => $user));

        # 返回数据
        $this->getResult()->addValue('result', 'user_name', $user);
        $this->getResult()->addValue('result', 'user_touched', $user_touch_time);

        return true;
    }

    # 定义API模块说明
    protected function getDescription()
    {
        # 请勿调用基类函数
        return '本API插件用于获取指定用户的最后活动时间';
    }

    # 定义API参数列表
    protected function getAllowedParams()
    {
        # 请勿调用基类函数
        return array('user' => array (ApiBase::PARAM_TYPE => 'string', ApiBase::PARAM_REQUIRED => true));
    }

    # 定义API参数说明
    protected function getParamDescription()
    {
        # 请勿调用基类函数
        return array('user' => '用户姓名');
    }

    # 提供API帮助的示例列表(api.php -> API模块名 -> Examples)
    # + getExamples():
    #   Returns usage examples for this module.
    #   Return value as an array is either:
    #       numeric keys with partial URLs ("api.php?" plus a query string) as values
    #           -> array('api.php?xxx', 'api.php?yyy');
    #       sequential numeric keys with even-numbered keys being display-text and odd-numbered keys being partial urls
    #           -> array('api.php?xxx', 'desc1', ''api.php?yyy', 'desc2')
    #       partial URLs as keys with display-text (string or array-to-be-joined) as values
    #           -> array(''api.php?xxx'=>'desc1', ''api.php?yyy'=>'desc2');
    #   Return value as a string is the same as an array with a numeric key and that value, and boolean false means "no examples".
    # + getExamplesMessages(): 1.25+
    #    Returns usage examples for this module.
    #    Return value has query strings as keys, with values being either strings (message key), arrays (message key + parameter), or Message objects.
    # *** Do not call this base class implementation when overriding this method ***
    protected function getExamples()
    {
        return array('api.php?action=user_touch_time&user=周京晖' => '查询周京晖的最后活动时间');
        # return false; -> no examples
    }
}
