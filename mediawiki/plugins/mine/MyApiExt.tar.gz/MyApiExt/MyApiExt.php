<?php

if (!defined('MEDIAWIKI'))
{
    die("This is a MediaWiki extension, don't run it directly!");
}

# 用于在"Special:Version"中显示信息
# 'specialpage' —> reserved for additions to MediaWiki Special Pages;
# 'parserhook'  —> used if your extension modifies, complements, or replaces the parser functions in MediaWiki;
# 'variable'    —> extension that add multiple functionality to MediaWiki;
# 'media'       —> used if your extension is a media handler of some sort
# 'api'         -> api modules
# 'other'       —> all other extensions
$wgExtensionCredits['api'][] = array(
    'path'           => __FILE__,
    'name'           => 'My API Extension',
    'version'        => '1.0',
    'author'         => 'zhoujh',
    'url'            => 'https://www.mediawiki.org/wiki/Extension:MyApiExt',
    'descriptionmsg' => 'my-api-ext-desc', # Message key in i18n file, 必须: 唯一, 小写, 无空格
    'description'    => 'This extension gets timestamp of the latest activity performed by a specified user'
);

$wgMessagesDirs['MyApiExt'] = __DIR__ . '/i18n';
$wgExtensionMessagesFiles['MyApiExt'] = __DIR__ . '/MyApiExt.i18n.php'; # MediaWiki-1.23+ 建议使用i18n/*.json

#-------------------------------------------------------------------------------

# Map class name to filename for autoloading
$wgAutoloadClasses['ApiUserTouchTime'] = __DIR__ . '/ApiMyExt.php';

# Map module name to class name
$wgAPIModules['user_touch_time'] = 'ApiUserTouchTime'; # action=xxx
# $wgAPIPropModules # prop=modules
# $wgAPIMetaModules # meta=modules
# $wgAPIListModules # list=modules

# Return true so that MediaWiki continues to load extensions.
return true;
