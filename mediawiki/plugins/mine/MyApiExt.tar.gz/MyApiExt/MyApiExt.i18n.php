<?php

# MediaWiki-1.23+ 建议使用i18n/*.json
