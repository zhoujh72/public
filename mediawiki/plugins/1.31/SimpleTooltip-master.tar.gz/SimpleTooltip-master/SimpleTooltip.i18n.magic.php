<?php
/**
 * Internationalisation file for magic words
 *
 * @file
 * @ingroup Extensions
 */

$magicWords = array();

/** English (English) */
$magicWords['en'] = array(
    'simple-tooltip' => array(0, 'simple-tooltip'),
    'simple-tooltip-info' => array(0, 'simple-tooltip-info'),
    'simple-tooltip-img' => array(0, 'simple-tooltip-img'),
    'tip-text' => array(0, 'tip-text'),
    'tip-info' => array(0, 'tip-info'),
    'tip-img' => array(0, 'tip-img'),
);
