<?php
/**
 * @ingroup Cargo
 */

$magicWords = array();

/** English (English) */
$magicWords['en'] = array(
	'cargo_declare' => array( 0, 'cargo_declare' ),
	'cargo_attach' => array( 0, 'cargo_attach' ),
	'cargo_store' => array( 0, 'cargo_store' ),
	'cargo_query' => array( 0, 'cargo_query' ),
	'cargo_compound_query' => array( 0, 'cargo_compound_query' ),
	'cargo_display_map' => array( 0, 'cargo_display_map' ),
	'recurring_event' => array( 0, 'recurring_event' ),
);
