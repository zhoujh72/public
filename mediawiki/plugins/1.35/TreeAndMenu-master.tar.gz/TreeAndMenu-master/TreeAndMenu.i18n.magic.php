<?php
/**
 * Internationalization file for magic words.
 */

$magicWords = array();

$magicWords['en'] = array(
	'menu' => array( 0, 'menu' ),
	'tree' => array( 0, 'tree' ),
	'_tree' => array( 0, '_tree' ),
);
